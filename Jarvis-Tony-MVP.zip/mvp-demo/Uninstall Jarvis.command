#!/bin/bash
set -euo pipefail

SUPPORT_DIR="${HOME:?}/Library/Application Support/Jarvis Demo"
LOG_DIR="$HOME/Library/Logs/Jarvis Demo"
PLIST="$HOME/Library/LaunchAgents/com.imclab.jarvis-demo.plist"
LAUNCHER="$HOME/Applications/Jarvis Demo.app"
TRASH_DIR="$HOME/.Trash/Jarvis Demo Uninstalled $(date -u +%Y%m%dT%H%M%SZ)"
SECURITY_BIN="${JARVIS_SECURITY_BIN:-/usr/bin/security}"

read -r -p "Uninstall Jarvis Demo, delete its saved source text, profile, conversation memory, usage and feedback logs, and remove its Keychain credentials? [y/N]: " confirm
[[ "$confirm" =~ ^[Yy]$ ]] || exit 0

subject=""
NODE_BIN=$(command -v node 2>/dev/null || true)
if [ -x "$SUPPORT_DIR/runtime/node-v24.19.0/bin/node" ]; then
  NODE_BIN="$SUPPORT_DIR/runtime/node-v24.19.0/bin/node"
fi
if [ -f "$SUPPORT_DIR/config.json" ] && [ -n "$NODE_BIN" ]; then
  subject=$("$NODE_BIN" -e 'try{process.stdout.write(JSON.parse(require("fs").readFileSync(process.argv[1],"utf8")).googleAccountSubject||"")}catch{}' "$SUPPORT_DIR/config.json")
fi
launchctl bootout "gui/$UID" "$PLIST" >/dev/null 2>&1 || true
# The selected source text, the profile, the usage and feedback logs, and the server logs are
# deleted outright, never trashed.
rm -f "$SUPPORT_DIR/context.json" "$SUPPORT_DIR/context.json.tmp" \
  "$SUPPORT_DIR/profile.json" "$SUPPORT_DIR/profile.json.tmp" \
  "$SUPPORT_DIR/usage.jsonl" "$SUPPORT_DIR/feedback.jsonl" "$SUPPORT_DIR/memory.jsonl"
rm -rf "$LOG_DIR"
mkdir -p "$TRASH_DIR"
[ ! -e "$SUPPORT_DIR" ] || mv "$SUPPORT_DIR" "$TRASH_DIR/Application Support"
[ ! -e "$LAUNCHER" ] || mv "$LAUNCHER" "$TRASH_DIR/Jarvis Demo.app"
[ ! -e "$PLIST" ] || mv "$PLIST" "$TRASH_DIR/com.imclab.jarvis-demo.plist"
"$SECURITY_BIN" delete-generic-password -a "$USER" -s com.imclab.jarvis-demo.openai >/dev/null 2>&1 || true
"$SECURITY_BIN" delete-generic-password -a "$USER" -s com.imclab.jarvis-demo.google-client-secret >/dev/null 2>&1 || true
[ -z "$subject" ] || "$SECURITY_BIN" delete-generic-password -a "$subject" -s com.imclab.jarvis-demo.google-refresh >/dev/null 2>&1 || true
echo "Jarvis Demo was moved to Trash. Its saved source text, profile, usage and feedback logs, server logs, and Keychain credentials were deleted."
