// Moves a demo install to native Jarvis without Terminal. Off until the signed native manifest says
// `demoMigrate: true` and this Mac meets its minimum macOS; nothing is downloaded before both hold.
import { execFile, spawn } from 'node:child_process';
import { createHash, createPublicKey } from 'node:crypto';
import { closeSync, constants, openSync } from 'node:fs';
import { access, mkdir, readFile, rm, stat, writeFile } from 'node:fs/promises';
import { homedir } from 'node:os';
import { join } from 'node:path';
import { promisify } from 'node:util';
import { verifyManifest } from './update.mjs';

const execFileAsync = promisify(execFile);
const MANIFEST_URL =
  'https://raw.githubusercontent.com/JT5D/jarvis-releases/main/native/manifest.json';
const TRUSTED_ASSET_PREFIX = 'https://github.com/JT5D/jarvis-releases/releases/download/native-v';
// The native manifest is signed with the native release key, not the demo's legacy key; this must
// equal apps/macos/Jarvis/Resources/NativeReleaseKey.txt (tested).
export const NATIVE_RELEASE_PUBLIC_KEY = 'UHlaRYRlAkH+3rIUpwQLYSx1isKpqkaeKLh/vXkkCgQ=';
const supportRoot = join(homedir(), 'Library', 'Application Support', 'Jarvis Demo');
const nativeSupportRoot = join(homedir(), 'Library', 'Application Support', 'Jarvis');
const launcher = join(homedir(), 'Applications', 'Jarvis Demo.app');
const legacyPlist = join(homedir(), 'Library', 'LaunchAgents', 'com.imclab.jarvis-demo.plist');

export function nativePublicKeyPem(raw = NATIVE_RELEASE_PUBLIC_KEY) {
  const spki = Buffer.concat([
    Buffer.from('302a300506032b6570032100', 'hex'),
    Buffer.from(raw, 'base64'),
  ]);
  return createPublicKey({ key: spki, format: 'der', type: 'spki' })
    .export({ type: 'spki', format: 'pem' })
    .toString();
}

/** "15.0" style comparison; an unreadable version never qualifies. */
export function meetsMinimumMacOS(version, minimum) {
  const parts = (value) =>
    String(value ?? '')
      .split('.')
      .map(Number);
  const [have, need] = [parts(version), parts(minimum)];
  if (!Number.isFinite(have[0]) || have[0] < 1) return false;
  for (let index = 0; index < need.length; index += 1) {
    const a = have[index] ?? 0;
    const b = need[index] ?? 0;
    if (a !== b) return a > b;
  }
  return true;
}

/** One install path shared with the DMG and the updater; ~/Applications only if that is not writable. */
export async function chooseInstallTarget({ canWrite = writable, home = homedir() } = {}) {
  if (await canWrite('/Applications')) return '/Applications/Jarvis.app';
  await mkdir(join(home, 'Applications'), { recursive: true });
  return join(home, 'Applications', 'Jarvis.app');
}

async function writable(path) {
  try {
    await access(path, constants.W_OK);
    return true;
  } catch {
    return false;
  }
}

async function macOSVersion() {
  try {
    return (await execFileAsync('/usr/bin/sw_vers', ['-productVersion'])).stdout.trim();
  } catch {
    return '';
  }
}

export function parseNativeManifest(text) {
  const value = JSON.parse(text);
  if (
    value.schemaVersion !== '1.0' ||
    value.product !== 'Jarvis' ||
    value.channel !== 'executive-preview'
  )
    throw new Error('native manifest identity is invalid');
  if (!/^\d+\.\d+\.\d+$/u.test(String(value.version ?? '')))
    throw new Error('native manifest version is invalid');
  if (!Number.isInteger(value.build) || value.build < 1) throw new Error('native build is invalid');
  if (typeof value.zip !== 'string' || !value.zip.startsWith(TRUSTED_ASSET_PREFIX))
    throw new Error('native zip URL is outside the public release repository');
  if (!/^[0-9a-f]{64}$/u.test(String(value.sha256 ?? '')))
    throw new Error('native zip checksum is invalid');
  return {
    version: value.version,
    build: value.build,
    zip: value.zip,
    sha256: value.sha256,
    commit: String(value.commit ?? ''),
    demoMigrate: value.demoMigrate === true,
    minimumMacOS: /^\d+(\.\d+){0,2}$/u.test(String(value.minimumMacOS))
      ? value.minimumMacOS
      : '15.0',
  };
}

export async function checkAndMigrateToNative({
  publicKeyPem = nativePublicKeyPem(),
  fetchImpl = fetch,
  osVersion = macOSVersion,
  installId,
  demoVersion,
  log = () => {},
  exitProcess = () => process.exit(0),
} = {}) {
  const [manifestText, signature] = await Promise.all([
    fetchText(fetchImpl, MANIFEST_URL),
    fetchText(fetchImpl, `${MANIFEST_URL}.sig`),
  ]);
  if (!verifyManifest(manifestText, signature, publicKeyPem)) {
    log('native manifest signature invalid; staying on legacy preview');
    return { status: 'bad-signature' };
  }
  const manifest = parseNativeManifest(manifestText);
  if (!manifest.demoMigrate) return { status: 'not-enabled' };
  const macOS = await osVersion();
  if (!meetsMinimumMacOS(macOS, manifest.minimumMacOS)) {
    log(`native Jarvis needs macOS ${manifest.minimumMacOS}; this Mac has ${macOS || 'unknown'}`);
    return { status: 'macos-too-old', macOS };
  }
  const migrationMarker = join(supportRoot, 'native-migration.json');
  try {
    const prior = JSON.parse(await readFile(migrationMarker, 'utf8'));
    if (Number(prior.build) >= manifest.build && prior.status === 'healthy') {
      return { status: 'already-migrated', version: prior.version };
    }
  } catch {
    log('no healthy prior native migration marker');
  }

  log(`staging native Jarvis ${manifest.version} (${manifest.build})`);
  const response = await fetchImpl(manifest.zip, { cache: 'no-store' });
  if (!response.ok) throw new Error(`native update download failed (${response.status})`);
  const bytes = Buffer.from(await response.arrayBuffer());
  if (createHash('sha256').update(bytes).digest('hex') !== manifest.sha256) {
    return { status: 'bad-checksum' };
  }

  const stageRoot = join(nativeSupportRoot, 'LegacyMigration', String(manifest.build));
  const zipPath = join(stageRoot, 'Jarvis.app.zip');
  const extractRoot = join(stageRoot, 'extract');
  await rm(stageRoot, { recursive: true, force: true });
  await mkdir(extractRoot, { recursive: true, mode: 0o700 });
  await writeFile(zipPath, bytes, { mode: 0o600 });
  await execFileAsync('/usr/bin/ditto', ['-x', '-k', zipPath, extractRoot]);
  const candidate = join(extractRoot, 'Jarvis.app');
  await stat(join(candidate, 'Contents', 'MacOS', 'Jarvis'));
  await verifyNativeCandidate(candidate, manifest);

  const nativeTarget = await chooseInstallTarget();
  // Nothing secret here: native copies the demo's key into its own Keychain item by running
  // /usr/bin/security (no prompt), and imports the profile and history from this folder.
  await mkdir(supportRoot, { recursive: true, mode: 0o700 });
  await writeFile(
    join(supportRoot, 'handoff.json'),
    `${JSON.stringify({ schemaVersion: 1, installId, demoVersion, target: nativeTarget, createdAt: new Date().toISOString() })}\n`,
    { mode: 0o600 },
  );

  const helper = join(stageRoot, 'migrate.sh');
  const script = `#!/bin/bash
set -u
uid="$1"
plist="$2"
candidate="$3"
target="$4"
launcher="$5"
marker="$6"
version="$7"
build="$8"
backup="\${target}.previous"
failed="\${target}.failed"
launchctl bootout "gui/$uid" "$plist" >/dev/null 2>&1 || true
sleep 0.5
rm -rf "$backup"
if [ -d "$target" ]; then mv "$target" "$backup" || exit 31; fi
if ! mv "$candidate" "$target"; then
  [ -d "$backup" ] && mv "$backup" "$target"
  launchctl bootstrap "gui/$uid" "$plist" >/dev/null 2>&1 || true
  launchctl kickstart -k "gui/$uid/com.imclab.jarvis-demo" >/dev/null 2>&1 || true
  exit 32
fi
/usr/bin/open "$target"
healthy=0
for _ in $(seq 1 80); do
  if /usr/bin/curl --silent --fail --max-time 1 http://127.0.0.1:48717/health >/dev/null 2>&1; then healthy=1; break; fi
  sleep 0.25
done
if [ "$healthy" -eq 1 ]; then
  migrated_at=$(date -u +%Y-%m-%dT%H:%M:%SZ)
  printf '{"status":"healthy","version":"%s","build":%s,"migratedAt":"%s"}\n' "$version" "$build" "$migrated_at" > "$marker"
  chmod 600 "$marker"
  rm -rf "$backup"
  rm -f "$plist"
  if [ -d "$launcher" ]; then mv "$launcher" "$HOME/.Trash/Jarvis Demo-migrated-$(date -u +%Y%m%dT%H%M%SZ).app" 2>/dev/null || true; fi
  exit 0
fi
/usr/bin/pkill -x Jarvis >/dev/null 2>&1 || true
sleep 0.5
rm -rf "$failed"
mv "$target" "$failed" 2>/dev/null || true
if [ -d "$backup" ]; then mv "$backup" "$target"; fi
launchctl bootstrap "gui/$uid" "$plist" >/dev/null 2>&1 || true
launchctl kickstart -k "gui/$uid/com.imclab.jarvis-demo" >/dev/null 2>&1 || true
exit 33
`;
  await writeFile(helper, script, { mode: 0o700 });

  // The helper stops the demo's launch agent, and launchd kills that job's whole process group, so
  // it runs in its own session with no pipes back to this process (a closed pipe would SIGPIPE it).
  const output = openSync(join(stageRoot, 'migrate.log'), 'a', 0o600);
  const child = spawn(
    '/bin/bash',
    [
      helper,
      String(process.getuid()),
      legacyPlist,
      candidate,
      nativeTarget,
      launcher,
      migrationMarker,
      manifest.version,
      String(manifest.build),
    ],
    { detached: true, stdio: ['ignore', output, output] },
  );
  closeSync(output);
  child.unref();
  log(
    'native migration helper started; legacy service will stop only after staging and verification passed',
  );
  setTimeout(exitProcess, 200).unref();
  return { status: 'migrating', version: manifest.version, build: manifest.build };
}

export function scheduleNativeMigration({
  initialDelayMs = 60_000,
  intervalMs = 6 * 3_600_000,
  ...options
} = {}) {
  let running = false;
  const tick = async () => {
    if (running) return;
    running = true;
    try {
      await checkAndMigrateToNative(options);
    } catch (error) {
      options.log?.(`native migration check failed: ${error.message}`);
    } finally {
      running = false;
    }
  };
  setTimeout(tick, initialDelayMs).unref();
  setInterval(tick, intervalMs).unref();
}

async function verifyNativeCandidate(candidate, manifest) {
  const info = join(candidate, 'Contents', 'Info.plist');
  const [{ stdout: bundleId }, { stdout: version }, { stdout: build }] = await Promise.all([
    execFileAsync('/usr/bin/defaults', ['read', info, 'CFBundleIdentifier']),
    execFileAsync('/usr/bin/defaults', ['read', info, 'CFBundleShortVersionString']),
    execFileAsync('/usr/bin/defaults', ['read', info, 'CFBundleVersion']),
  ]);
  if (bundleId.trim() !== 'com.imclab.jarvis') throw new Error('native bundle identifier mismatch');
  if (version.trim() !== manifest.version || Number(build.trim()) !== manifest.build)
    throw new Error('native bundle version mismatch');
  await execFileAsync('/usr/bin/codesign', ['--verify', '--deep', '--strict', candidate]);
  await execFileAsync('/usr/sbin/spctl', [
    '--assess',
    '--type',
    'execute',
    '--verbose=2',
    candidate,
  ]);
}

async function fetchText(fetchImpl, url) {
  const response = await fetchImpl(url, { cache: 'no-store' });
  if (!response.ok) throw new Error(`${url} answered ${response.status}`);
  return response.text();
}
