const OPENAI_API_ROOT = 'https://api.openai.com/v1';

export async function verifyOpenAIAccess({ apiKey, textModel, realtimeModel, fetchImpl = fetch }) {
  if (!apiKey) throw new Error('No OpenAI API key was found in macOS Keychain.');

  const headers = {
    Authorization: `Bearer ${apiKey}`,
    'Content-Type': 'application/json',
  };

  const warnings = [];

  const textResponse = await request(
    fetchImpl,
    `${OPENAI_API_ROOT}/responses`,
    {
      method: 'POST',
      headers,
      body: JSON.stringify({
        model: textModel,
        input: 'Reply exactly: OK',
        max_output_tokens: 64,
        store: false,
      }),
      signal: AbortSignal.timeout(30_000),
    },
    'text',
  );
  const textResult = await ensureSuccess(textResponse, 'text');
  if (textResult.warning) warnings.push(textResult.warning);

  const realtimeResponse = await request(
    fetchImpl,
    `${OPENAI_API_ROOT}/realtime/client_secrets`,
    {
      method: 'POST',
      headers,
      body: JSON.stringify({
        session: {
          type: 'realtime',
          model: realtimeModel,
          audio: { output: { voice: 'marin' } },
        },
      }),
      signal: AbortSignal.timeout(30_000),
    },
    'voice',
  );
  const voiceResult = await ensureSuccess(realtimeResponse, 'voice');
  if (voiceResult.warning) warnings.push(voiceResult.warning);

  return { textModel, realtimeModel, warnings };
}

async function request(fetchImpl, url, options, capability) {
  try {
    return await fetchImpl(url, options);
  } catch {
    throw new Error(
      `Could not reach OpenAI for the ${capability} check. Check the internet connection and try again.`,
    );
  }
}

async function ensureSuccess(response, capability) {
  if (response.ok) return { ok: true };

  const payload = await response.json().catch(() => ({}));
  const code = String(payload?.error?.code || '');
  const type = String(payload?.error?.type || '');
  const detail = code || type || `HTTP ${response.status}`;

  if (response.status === 401 || code === 'invalid_api_key') {
    throw new Error(
      `OpenAI rejected the API key during the ${capability} check. Create a new project API key and try again.`,
    );
  }

  if (response.status === 403) {
    throw new Error(
      `The OpenAI key does not have ${capability} access (${detail}). Use a project key with the required permissions.`,
    );
  }

  if (
    code === 'insufficient_quota' ||
    code === 'billing_not_active' ||
    code === 'credit_balance_exhausted'
  ) {
    throw new Error(
      `OpenAI ${capability} access is blocked by API billing or credits (${detail}). Check OpenAI API billing and try again.`,
    );
  }

  // A temporary request-rate limit does not make the key invalid and should not brick installation.
  // Jarvis can start and retry naturally once the limit clears.
  if (response.status === 429 || code === 'rate_limit_exceeded' || type === 'rate_limit_error') {
    return {
      ok: false,
      warning: `OpenAI ${capability} verification was temporarily rate-limited (${detail}). Jarvis will install and retry when you use it.`,
    };
  }

  if (response.status === 404 || code === 'model_not_found') {
    throw new Error(
      `The required OpenAI ${capability} model is unavailable for this project (${detail}).`,
    );
  }

  throw new Error(`OpenAI ${capability} check failed (${detail}).`);
}
