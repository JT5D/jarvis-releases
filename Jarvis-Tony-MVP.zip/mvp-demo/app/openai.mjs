const OPENAI_API_ROOT = 'https://api.openai.com/v1';

export async function verifyOpenAIAccess({ apiKey, textModel, realtimeModel, fetchImpl = fetch }) {
  if (!apiKey) throw new Error('No OpenAI API key was found in macOS Keychain.');

  const headers = {
    Authorization: `Bearer ${apiKey}`,
    'Content-Type': 'application/json',
  };

  const textResponse = await request(
    fetchImpl,
    `${OPENAI_API_ROOT}/responses`,
    {
      method: 'POST',
      headers,
      body: JSON.stringify({
        model: textModel,
        input: 'Reply exactly: OK',
        max_output_tokens: 64,
        store: false,
      }),
      signal: AbortSignal.timeout(30_000),
    },
    'text',
  );
  await ensureSuccess(textResponse, 'text');

  const realtimeResponse = await request(
    fetchImpl,
    `${OPENAI_API_ROOT}/realtime/client_secrets`,
    {
      method: 'POST',
      headers,
      body: JSON.stringify({
        session: {
          type: 'realtime',
          model: realtimeModel,
          audio: { output: { voice: 'marin' } },
        },
      }),
      signal: AbortSignal.timeout(30_000),
    },
    'voice',
  );
  await ensureSuccess(realtimeResponse, 'voice');

  return { textModel, realtimeModel };
}

async function request(fetchImpl, url, options, capability) {
  try {
    return await fetchImpl(url, options);
  } catch {
    throw new Error(
      `Could not reach OpenAI for the ${capability} check. Check the internet connection and try again.`,
    );
  }
}

async function ensureSuccess(response, capability) {
  if (response.ok) return;
  const payload = await response.json().catch(() => ({}));
  const code = payload?.error?.code;
  const detail = code || `HTTP ${response.status}`;

  if (response.status === 401 || code === 'invalid_api_key') {
    throw new Error('OpenAI rejected the API key. Create a new project API key and try again.');
  }
  if (response.status === 403) {
    throw new Error(
      `The OpenAI key does not have ${capability} access. Use a project key with default All permissions.`,
    );
  }
  if (
    response.status === 429 ||
    code === 'insufficient_quota' ||
    code === 'billing_not_active' ||
    code === 'credit_balance_exhausted'
  ) {
    throw new Error(
      'OpenAI API billing, credits, or rate limits are not ready. Check API billing, wait a few minutes, and try again.',
    );
  }
  if (response.status === 404 || code === 'model_not_found') {
    throw new Error(
      `The required OpenAI ${capability} model is unavailable for this project (${detail}).`,
    );
  }
  throw new Error(`OpenAI ${capability} check failed (${detail}).`);
}
