import test from 'node:test';
import assert from 'node:assert/strict';
import { execFile } from 'node:child_process';
import { createHash, generateKeyPairSync, sign } from 'node:crypto';
import { once } from 'node:events';
import { mkdir, mkdtemp, readFile, rm, stat, writeFile } from 'node:fs/promises';
import http from 'node:http';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { promisify } from 'node:util';
import { checkForUpdate, parseManifest, parseVersion, verifyManifest } from '../update.mjs';

const skip = process.platform === 'darwin' ? false : 'the updater unpacks with macOS ditto';
const execFileAsync = promisify(execFile);
const { publicKey, privateKey } = generateKeyPairSync('ed25519');
const publicKeyPem = publicKey.export({ type: 'spki', format: 'pem' });
const signManifest = (text) => sign(null, Buffer.from(text), privateKey).toString('base64');

async function writeApp(dir, version) {
  await mkdir(dir, { recursive: true });
  await writeFile(join(dir, 'server.mjs'), `process.stdout.write('${version}');\n`);
  await writeFile(join(dir, 'release.json'), JSON.stringify({ version, commit: 'abc' }));
}

// A sandbox with the installed app at <root>/app (v13) and a release ZIP for v14 served over
// loopback, shaped like the real one: mvp-demo/app/... inside the archive.
async function sandbox({ zipVersion = 'tony-mvp-v14', manifestPatch = {}, breakSignature } = {}) {
  const root = await mkdtemp(join(tmpdir(), 'jarvis-update-'));
  const appDir = join(root, 'app');
  await writeApp(appDir, 'tony-mvp-v13');
  await writeApp(join(root, 'src', 'mvp-demo', 'app'), zipVersion);
  const zipPath = join(root, 'Jarvis-Tony-MVP.zip');
  await execFileAsync('/usr/bin/ditto', ['-c', '-k', '--keepParent', 'mvp-demo', zipPath], {
    cwd: join(root, 'src'),
  });
  const zip = await readFile(zipPath);
  const files = new Map();
  const server = http.createServer((request, response) => {
    const body = files.get(request.url);
    if (body === undefined) return response.writeHead(404).end();
    response.writeHead(200).end(body);
  });
  server.listen(0, '127.0.0.1');
  await once(server, 'listening');
  const origin = `http://127.0.0.1:${server.address().port}`;
  const manifest = JSON.stringify({
    version: 'tony-mvp-v14',
    zip: `${origin}/Jarvis-Tony-MVP.zip`,
    sha256: createHash('sha256').update(zip).digest('hex'),
    commit: 'abc',
    ...manifestPatch,
  });
  const signature = signManifest(manifest);
  files.set('/manifest.json', manifest);
  files.set(
    '/manifest.json.sig',
    breakSignature ? signature.replace(/^./u, (char) => (char === 'A' ? 'B' : 'A')) : signature,
  );
  files.set('/Jarvis-Tony-MVP.zip', zip);
  const log = [];
  return {
    appDir,
    run: (currentVersion = 'tony-mvp-v13') =>
      checkForUpdate({
        manifestUrl: `${origin}/manifest.json`,
        allowedZipPrefix: origin,
        publicKeyPem,
        currentVersion,
        appDir,
        log: (line) => log.push(line),
      }),
    log,
    version: async (dir) => JSON.parse(await readFile(join(dir, 'release.json'), 'utf8')).version,
    async cleanup() {
      server.close();
      await rm(root, { recursive: true, force: true });
    },
  };
}

const exists = (path) =>
  stat(path).then(
    () => true,
    () => false,
  );

test('release tags parse to numbers and anything else is not a version', () => {
  assert.equal(parseVersion('tony-mvp-v14'), 14);
  assert.ok(Number.isNaN(parseVersion('v14')));
  assert.ok(Number.isNaN(parseVersion('tony-mvp-v14; rm -rf /')));
});

test('the manifest is trusted only with a valid signature and an in-repo zip URL', () => {
  const text = JSON.stringify({
    version: 'tony-mvp-v2',
    zip: 'https://raw.githubusercontent.com/JT5D/jarvis-releases/main/Jarvis-Tony-MVP.zip',
    sha256: 'a'.repeat(64),
  });
  assert.equal(verifyManifest(text, signManifest(text), publicKeyPem), true);
  assert.equal(verifyManifest(`${text} `, signManifest(text), publicKeyPem), false);
  assert.equal(verifyManifest(text, 'not-base64-signature', publicKeyPem), false);
  assert.equal(parseManifest(text).number, 2);
  assert.throws(
    () => parseManifest(text.replace('JT5D/jarvis-releases', 'evil/jarvis-releases')),
    /outside the releases repo/u,
  );
});

test('a newer signed build is swapped in and the previous app is kept', { skip }, async () => {
  const box = await sandbox();
  try {
    const result = await box.run();
    assert.deepEqual(result, { status: 'updated', version: 'tony-mvp-v14' });
    assert.equal(await box.version(box.appDir), 'tony-mvp-v14');
    assert.equal(await box.version(`${box.appDir}-old`), 'tony-mvp-v13');
    assert.equal(await exists(`${box.appDir}-new`), false, 'staging dir must be cleaned');
    assert.equal(await exists(`${box.appDir}-update.zip`), false, 'zip must be cleaned');
    assert.match(box.log.at(-1), /updated to tony-mvp-v14/u);
    assert.deepEqual(await box.run('tony-mvp-v14'), {
      status: 'current',
      version: 'tony-mvp-v14',
      latest: 14,
    });
  } finally {
    await box.cleanup();
  }
});

test(
  'a tampered signature, a wrong checksum, or a mismatched zip changes nothing',
  { skip },
  async () => {
    const cases = [
      { options: { breakSignature: true }, status: 'bad-signature' },
      { options: { manifestPatch: { sha256: 'b'.repeat(64) } }, status: 'bad-checksum' },
      { options: { zipVersion: 'tony-mvp-v99' }, status: 'mismatch' },
    ];
    for (const { options, status } of cases) {
      const box = await sandbox(options);
      try {
        assert.equal((await box.run()).status, status);
        assert.equal(await box.version(box.appDir), 'tony-mvp-v13', `${status} must not touch app`);
        assert.equal(await exists(`${box.appDir}-old`), false, `${status} must not create app-old`);
        assert.equal(await exists(`${box.appDir}-new`), false);
        assert.equal(await exists(`${box.appDir}-update.zip`), false);
      } finally {
        await box.cleanup();
      }
    }
  },
);
