import assert from 'node:assert/strict';
import { mkdtemp, readFile, rm } from 'node:fs/promises';
import { readFileSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import test from 'node:test';
import {
  buildReport,
  FIELDS,
  recordLaunch,
  REPORT_URL,
  scheduleInstallReports,
  senseHost,
} from '../install-report.mjs';

const repo = (path) => new URL(`../../../${path}`, import.meta.url);
const schema = JSON.parse(readFileSync(repo('apps/install-report/fields.json'), 'utf8'));

test('the demo sends exactly the allowlisted fields to the same sink as native Jarvis', () => {
  assert.deepEqual(FIELDS, schema.fields);
  assert.equal(
    REPORT_URL,
    readFileSync(repo('apps/macos/Jarvis/Resources/InstallReportURL.txt'), 'utf8').trim(),
  );
  const report = buildReport({
    installId: '0f8fad5b-d9cb-469f-a165-70867728950e',
    reason: 'launch',
    version: 'tony-mvp-v41',
    launches: 3,
    openAIKeyStored: true,
    update: { result: 'up-to-date', latestBuild: 41, checkedAt: '2026-09-14T21:00:00.000Z' },
    host: { macOSVersion: '14.6.1', macModel: 'Mac14,2', chip: 'Apple M2', memoryGB: 16 },
  });
  assert.deepEqual(Object.keys(report), schema.fields);
  for (const forbidden of schema.neverSend) assert.equal(forbidden in report, false, forbidden);
  assert.equal(report.channel, 'demo');
  assert.equal(report.appBuild, 41);
  assert.equal(report.macOSVersion, '14.6.1');
  assert.equal(report.appleIntelligence, 'unknown', 'what Node cannot sense is marked unknown');
  assert.equal(report.lastError, 'none');
});

test('nothing is sent while reports are off; the local copy is still written', async () => {
  const supportRoot = await mkdtemp(join(tmpdir(), 'jarvis-report-'));
  try {
    const posts = [];
    let enabled = false;
    const send = scheduleInstallReports({
      supportRoot,
      version: 'tony-mvp-v41',
      launch: { installId: '0f8fad5b-d9cb-469f-a165-70867728950e', launches: 1 },
      enabled: () => enabled,
      openAIKeyStored: () => true,
      update: () => ({}),
      sense: async () => ({ macOSVersion: '15.6' }),
      fetchImpl: async (url, init) => {
        posts.push({ url, body: JSON.parse(init.body) });
        return new Response('{}');
      },
      initialDelayMs: 3_600_000,
    });
    assert.equal(await send('launch'), 'off');
    assert.equal(posts.length, 0);
    const local = JSON.parse(await readFile(join(supportRoot, 'install-report.json'), 'utf8'));
    assert.equal(local.macOSVersion, '15.6');

    enabled = true;
    assert.equal(await send('daily'), 'sent');
    assert.equal(posts.length, 1);
    assert.equal(posts[0].url, REPORT_URL);
    assert.deepEqual(Object.keys(posts[0].body), schema.fields);
  } finally {
    await rm(supportRoot, { recursive: true, force: true });
  }
});

test('one install ID per Mac, launches counted across restarts', async () => {
  const supportRoot = await mkdtemp(join(tmpdir(), 'jarvis-report-'));
  try {
    const first = await recordLaunch(supportRoot);
    const second = await recordLaunch(supportRoot);
    assert.match(first.installId, /^[0-9a-f-]{36}$/u);
    assert.equal(second.installId, first.installId);
    assert.equal(second.launches, 2);
  } finally {
    await rm(supportRoot, { recursive: true, force: true });
  }
});

test('host sensing reads macOS, hardware and Low Power mode, and tolerates missing tools', async () => {
  const outputs = {
    '/usr/bin/sw_vers': '15.6.1',
    '/usr/sbin/sysctl -n hw.model': 'Mac15,9',
    '/usr/sbin/sysctl -n machdep.cpu.brand_string': 'Apple M3 Max',
    '/usr/bin/pmset': 'System-wide power settings:\n lowpowermode         1\n',
  };
  const host = await senseHost(async (file, args) =>
    file === '/usr/sbin/sysctl' ? outputs[`${file} ${args.join(' ')}`] : outputs[file],
  );
  assert.equal(host.macOSVersion, '15.6.1');
  assert.equal(host.chip, 'Apple M3 Max');
  assert.equal(host.lowPowerMode, true);
  const bare = await senseHost(async () => undefined);
  assert.equal(bare.macOSVersion, undefined);
  assert.equal(bare.lowPowerMode, undefined);
});
