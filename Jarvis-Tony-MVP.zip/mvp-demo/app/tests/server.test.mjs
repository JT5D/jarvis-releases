import test from 'node:test';
import assert from 'node:assert/strict';
import { spawn } from 'node:child_process';
import { once } from 'node:events';
import { mkdtemp, readFile, rm } from 'node:fs/promises';
import net from 'node:net';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { setTimeout as sleep } from 'node:timers/promises';
import { fileURLToPath } from 'node:url';

const serverPath = fileURLToPath(new URL('../server.mjs', import.meta.url));

async function freePort() {
  const probe = net.createServer().listen(0, '127.0.0.1');
  await once(probe, 'listening');
  const { port } = probe.address();
  probe.close();
  await once(probe, 'close');
  return port;
}

async function startServer({ workDir: reuse } = {}) {
  const port = await freePort();
  const workDir = reuse ?? (await mkdtemp(join(tmpdir(), 'jarvis-mvp-test-')));
  const child = spawn(process.execPath, [serverPath], {
    env: {
      ...process.env,
      OPENAI_API_KEY: 'sk-test-only',
      JARVIS_PORT: String(port),
      JARVIS_CONFIG_PATH: join(workDir, 'config.json'),
    },
    stdio: ['ignore', 'pipe', 'pipe'],
  });
  const logs = [];
  child.stdout.on('data', (chunk) => logs.push(String(chunk)));
  child.stderr.on('data', (chunk) => logs.push(String(chunk)));
  await new Promise((resolve, reject) => {
    child.stdout.on('data', (chunk) => String(chunk).includes('is ready at') && resolve());
    child.once('exit', (code) =>
      reject(new Error(`server exited early (${code}): ${logs.join('')}`)),
    );
  });
  return {
    child,
    logs,
    workDir,
    origin: `http://127.0.0.1:${port}`,
    async stop({ keepWorkDir = false } = {}) {
      // A SIGTERM-killed child has exitCode null and signalCode set; only kill a live process.
      if (child.exitCode === null && child.signalCode === null) {
        child.kill();
        await once(child, 'exit');
      }
      if (!keepWorkDir) await rm(workDir, { recursive: true, force: true });
    },
  };
}

function post(origin, path, body, headers = {}) {
  return fetch(`${origin}${path}`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json', Origin: origin, ...headers },
    body: JSON.stringify(body),
  });
}

test('an empty chat message returns a JSON error and keeps the server alive', async () => {
  const { child, logs, origin, stop } = await startServer();
  try {
    const response = await fetch(`${origin}/api/chat`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', Origin: origin },
      body: JSON.stringify({ message: '' }),
    }).catch((error) => error);
    assert.ok(
      response instanceof Response,
      `server dropped the request: ${response?.cause?.message || response?.message}`,
    );
    assert.ok(response.status >= 400 && response.status < 600, `unexpected ${response.status}`);
    assert.match((await response.json()).error, /between 1 and 4,000 characters/u);
    await sleep(250);
    assert.equal(child.exitCode, null, `server process exited: ${logs.join('')}`);
    const status = await fetch(`${origin}/api/status`);
    assert.equal(status.status, 200);
  } finally {
    await stop();
  }
});

test('a POST without an Origin header is rejected with 403 JSON and the server stays alive', async () => {
  const { child, logs, origin, stop } = await startServer();
  try {
    // No Origin at all (any local process), then a foreign one. Both must fail identically.
    const probes = [
      { path: '/api/chat', headers: {}, body: { message: '' } },
      { path: '/api/context', headers: {}, body: { name: 'seed.txt', content: 'seeded' } },
      { path: '/api/profile', headers: {}, body: { name: 'Mallory' } },
      { path: '/api/usage', headers: {}, body: { event: 'mic_denied' } },
      { path: '/api/feedback', headers: {}, body: { rating: 'down' } },
      { path: '/api/chat', headers: { Origin: 'http://evil.example' }, body: { message: '' } },
    ];
    for (const probe of probes) {
      const response = await fetch(`${origin}${probe.path}`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', ...probe.headers },
        body: JSON.stringify(probe.body),
      });
      const label = `${probe.path} with Origin=${probe.headers.Origin ?? '(none)'}`;
      assert.equal(response.status, 403, `${label} returned ${response.status}`);
      assert.match(response.headers.get('content-type'), /^application\/json/u);
      assert.deepEqual(await response.json(), { error: 'Origin rejected.' }, label);
    }
    await sleep(250);
    assert.equal(child.exitCode, null, `server process exited: ${logs.join('')}`);
    const status = await fetch(`${origin}/api/status`);
    assert.equal(status.status, 200);
    const payload = await status.json();
    assert.equal(payload.selectedFile, null, 'no-Origin POST must not seed context');
    assert.equal(payload.profile, null, 'no-Origin POST must not set a profile');

    // The browser's own origin still works: an empty message reaches the existing validation.
    const allowed = await fetch(`${origin}/api/chat`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', Origin: origin },
      body: JSON.stringify({ message: '' }),
    });
    assert.equal(allowed.status, 400);
    assert.match((await allowed.json()).error, /between 1 and 4,000 characters/u);
  } finally {
    await stop();
  }
});

test('first run has no profile; a saved profile is bounded and survives a restart', async () => {
  const first = await startServer();
  let second;
  try {
    const status = await (await fetch(`${first.origin}/api/status`)).json();
    assert.equal(status.profile, null, 'a fresh install must start with no profile');
    assert.deepEqual(status.voices, ['marin', 'cedar']);
    assert.match(status.version, /^\d+\.\d+\.\d+$/u);

    const refused = await post(first.origin, '/api/profile', { name: '  ' });
    assert.equal(refused.status, 400);
    assert.match((await refused.json()).error, /what to call you/u);

    const saved = await post(first.origin, '/api/profile', {
      name: ' James  Tunick ',
      role: 'CTO',
      style: 'detailed',
      voice: 'nonsense',
      apiKey: 'must be dropped',
    });
    assert.equal(saved.status, 200);
    assert.deepEqual((await saved.json()).profile, {
      name: 'James Tunick',
      role: 'CTO',
      style: 'detailed',
      voice: 'marin',
      memory: true,
      // Not requested above, so sight stays off: it is opt-in, unlike memory.
      vision: false,
    });

    await first.stop({ keepWorkDir: true });
    second = await startServer({ workDir: first.workDir });
    const restored = await (await fetch(`${second.origin}/api/status`)).json();
    assert.equal(restored.profile?.name, 'James Tunick', 'profile must survive a restart');
    assert.equal(restored.profile?.style, 'detailed');
  } finally {
    await first.stop({ keepWorkDir: true });
    await (second ?? first).stop();
  }
});

test('usage keeps counts and timings only, and the summary prefills a reviewable issue', async () => {
  const { origin, workDir, stop } = await startServer();
  try {
    await post(origin, '/api/profile', { name: 'Tony', role: 'CEO', voice: 'cedar' });
    await post(origin, '/api/usage', { event: 'voice_start' });
    for (const latencyMs of [900, 300, 600, 1200]) {
      const response = await post(origin, '/api/usage', {
        event: 'turn',
        kind: 'voice',
        latencyMs,
        content: 'the spoken words, which must never be stored',
      });
      assert.equal(response.status, 200);
    }
    await post(origin, '/api/usage', { event: 'turn', kind: 'text', latencyMs: 4000 });
    const unknown = await post(origin, '/api/usage', { event: 'transcript', text: 'secret' });
    assert.equal(unknown.status, 400, 'an unknown event type is refused');
    const noRating = await post(origin, '/api/feedback', { note: 'no thumbs' });
    assert.equal(noRating.status, 400);
    const rated = await post(origin, '/api/feedback', {
      rating: 'up',
      note: 'Voice felt quick.\n\nOne odd pause.',
    });
    assert.equal(rated.status, 200);

    const usageLog = await readFile(join(workDir, 'usage.jsonl'), 'utf8');
    assert.equal(usageLog.trim().split('\n').length, 6, 'one line per accepted event');
    assert.doesNotMatch(usageLog, /spoken words|secret|transcript/u, 'no text in the usage log');
    assert.match(usageLog, /"at":"\d{4}-\d{2}-\d{2}T/u, 'the server stamps the time');

    const summary = await (await fetch(`${origin}/api/feedback/summary`)).json();
    assert.equal(summary.voiceSessions, 1);
    assert.equal(summary.voiceTurns, 4);
    assert.equal(summary.textTurns, 1);
    assert.deepEqual(summary.latency, { samples: 4, p50Ms: 600, p95Ms: 1200 });
    assert.equal(summary.lastFeedback.rating, 'up');
    assert.equal(summary.lastFeedback.note, 'Voice felt quick. One odd pause.');

    const issue = new URL(summary.issueUrl);
    assert.equal(issue.origin + issue.pathname, 'https://github.com/JT5D/jarvis/issues/new');
    assert.equal(issue.searchParams.get('labels'), 'demo-feedback');
    assert.match(issue.searchParams.get('title'), /^Demo feedback from Tony: 👍$/u);
    const body = issue.searchParams.get('body');
    assert.match(body, /p50 600 ms · p95 1200 ms · n=4/u);
    assert.match(body, /1 voice sessions · 4 voice turns · 1 text turns/u);
    assert.match(body, /voice cedar/u);
    assert.match(body, /Voice felt quick\. One odd pause\./u);
    assert.doesNotMatch(body, /spoken words|secret/u, 'the issue never carries content');
  } finally {
    await stop();
  }
});

test('the perception endpoint stays silent until sight is switched on', async () => {
  const { origin, stop } = await startServer();
  try {
    await post(origin, '/api/profile', { name: 'James' });
    const off = await (await post(origin, '/api/perception', {})).json();
    assert.match(off.event.session.instructions, /cannot see their screen/);
    assert.equal(off.status, 'off', 'off must be distinguishable from a refused permission');

    await post(origin, '/api/profile', { name: 'James', vision: true });
    const on = await (await post(origin, '/api/perception', {})).json();
    // Either a real window or the blindness sentence — which one depends on whether this machine
    // granted Automation access. Never null once sight is on, and always a sendable event.
    assert.equal(on.event.type, 'session.update');
    // 'blocked' is what a refused Automation prompt looks like, and the UI needs to tell it apart
    // from 'off' to say anything useful about it.
    assert.ok(['seeing', 'blocked'].includes(on.status), `unexpected status ${on.status}`);
    if (on.status === 'blocked') assert.equal(on.app, null, 'a blocked read has no app to report');
    const said = on.event.session.instructions;
    assert.ok(
      /Frontmost app:/u.test(said) || /cannot see/iu.test(said),
      `unexpected perception payload: ${said}`,
    );
  } finally {
    await stop();
  }
});

test('a cross-origin page cannot read what window is open', async () => {
  const { origin, stop } = await startServer();
  try {
    await post(origin, '/api/profile', { name: 'James', vision: true });
    const response = await fetch(`${origin}/api/perception`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', Origin: 'https://evil.example' },
      body: '{}',
    });
    assert.ok(response.status >= 400, `cross-origin read was allowed (${response.status})`);
    const payload = await response.json();
    assert.ok(!('event' in payload), 'a rejected request must not leak the window title');
  } finally {
    await stop();
  }
});

test('what they were working in is written down once, not once per look', async () => {
  const { origin, workDir, stop } = await startServer();
  try {
    await post(origin, '/api/profile', { name: 'James', vision: true });
    // Three looks in quick succession, at the same desk.
    for (let i = 0; i < 3; i += 1) await post(origin, '/api/perception', {});
    const log = await readFile(join(workDir, 'memory.jsonl'), 'utf8').catch(() => '');
    const activity = log
      .split('\n')
      .filter(Boolean)
      .map((line) => JSON.parse(line))
      .filter((row) => row.app);
    // Blind on a machine with no Automation access: nothing to record, and that is correct.
    if (activity.length === 0) return;
    assert.equal(activity.length, 1, `the surprise gate let ${activity.length} rows through`);
    assert.ok(Number.isFinite(activity[0].t), 'an observation without a date cannot be past tense');
    assert.ok(activity[0].app, 'an observation must name the app');
  } finally {
    await stop();
  }
});

test('with remembering switched off, nothing about other apps is written down', async () => {
  const { origin, workDir, stop } = await startServer();
  try {
    await post(origin, '/api/profile', { name: 'James', vision: true, memory: false });
    await post(origin, '/api/perception', {});
    const log = await readFile(join(workDir, 'memory.jsonl'), 'utf8').catch(() => '');
    const activity = log
      .split('\n')
      .filter(Boolean)
      .map((line) => JSON.parse(line))
      .filter((row) => row.app);
    assert.equal(activity.length, 0, 'sight wrote to the log while remembering was off');
  } finally {
    await stop();
  }
});
