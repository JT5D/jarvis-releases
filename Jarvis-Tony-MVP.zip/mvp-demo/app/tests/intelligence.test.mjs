import test from 'node:test';
import assert from 'node:assert/strict';
import { execFileSync } from 'node:child_process';
import {
  buildInstructions,
  composeChatTurn,
  formatPerception,
  formatRecall,
  extractOpenAIText,
} from '../lib.mjs';

const historical = formatRecall([{ t: 1, app: 'Firefox', window: 'old news' }]);
const instructions = buildInstructions(
  { name: 'Brief', content: 'The launch is next week.', sourceId: 'test' },
  { name: 'Tony' },
);
test('general questions are not restricted to the attached brief', () => {
  assert.match(
    instructions,
    /General knowledge, spelling, and arithmetic do not require a local source/,
  );
  assert.match(instructions, /overrides all history/);
});
const live = process.env.JARVIS_LIVE_TEST === '1';
for (const scenario of [
  {
    name: 'spell cat',
    q: 'How do you spell cat?',
    view: null,
    yes: /c[\s*.,-]*a[\s*.,-]*t/i,
    no: /not.*source/i,
  },
  {
    name: 'historical Firefox is not current sight',
    q: 'Is Firefox open on my screen right now?',
    view: null,
    yes: /cannot|can.t|unable|don.t have|can’t/i,
    no: /^(Yes[, .]+)?Firefox is (currently )?open|you (are|’re) (in|using) Firefox/i,
  },
  {
    name: 'current Mail overrides historical Firefox',
    q: 'Which app is in front of me now?',
    view: { app: 'Mail', window: 'Inbox' },
    yes: /Mail/,
    no: /you (are|’re) (in|using) Firefox/i,
  },
  {
    name: 'unavailable sight is explicit',
    q: 'What do you see on my screen?',
    view: null,
    yes: /cannot|can.t|unable|don.t have|can’t/i,
    no: /you (are|’re) (in|using) Firefox/i,
  },
])
  test(`live: ${scenario.name}`, { skip: !live, timeout: 70000 }, async () => {
    const key =
      process.env.OPENAI_API_KEY ||
      execFileSync(
        '/usr/bin/security',
        [
          'find-generic-password',
          '-a',
          process.env.USER,
          '-s',
          'com.imclab.jarvis-demo.openai',
          '-w',
        ],
        { encoding: 'utf8', stdio: ['ignore', 'pipe', 'ignore'] },
      ).trim();
    const input = composeChatTurn({
      recalled: historical,
      seeing: formatPerception(scenario.view),
      question: scenario.q,
    }).input;
    const r = await fetch('https://api.openai.com/v1/responses', {
      method: 'POST',
      headers: { Authorization: `Bearer ${key}`, 'Content-Type': 'application/json' },
      body: JSON.stringify({
        model: 'gpt-5.6',
        instructions,
        input,
        max_output_tokens: 600,
        store: false,
      }),
      signal: AbortSignal.timeout(60000),
    });
    assert.equal(r.status, 200);
    const answer = extractOpenAIText(await r.json());
    assert.match(answer, scenario.yes);
    assert.doesNotMatch(answer, scenario.no);
    console.log(`${scenario.name}: ${answer}`);
  });
