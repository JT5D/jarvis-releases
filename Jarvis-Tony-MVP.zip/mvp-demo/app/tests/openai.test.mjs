import test from 'node:test';
import assert from 'node:assert/strict';
import { verifyOpenAIAccess } from '../openai.mjs';

const settings = {
  apiKey: 'sk-test-only',
  textModel: 'gpt-5.6',
  realtimeModel: 'gpt-realtime-2.1',
};

test('checks a real text request and Realtime session without exposing the key', async () => {
  const calls = [];
  const result = await verifyOpenAIAccess({
    ...settings,
    fetchImpl: async (url, options) => {
      calls.push({ url, options });
      return { ok: true, status: 200, json: async () => ({}) };
    },
  });

  assert.deepEqual(result, {
    textModel: 'gpt-5.6',
    realtimeModel: 'gpt-realtime-2.1',
  });
  assert.equal(calls[0].url, 'https://api.openai.com/v1/responses');
  assert.equal(JSON.parse(calls[0].options.body).store, false);
  assert.equal(calls[1].url, 'https://api.openai.com/v1/realtime/client_secrets');
  assert.equal(JSON.parse(calls[1].options.body).session.model, 'gpt-realtime-2.1');
  assert.equal(
    calls.every((call) => call.options.headers.Authorization === 'Bearer sk-test-only'),
    true,
  );
});

test('explains invalid API keys', async () => {
  await assert.rejects(
    verifyOpenAIAccess({
      ...settings,
      fetchImpl: async () => ({
        ok: false,
        status: 401,
        json: async () => ({ error: { code: 'invalid_api_key' } }),
      }),
    }),
    /rejected the API key/u,
  );
});

test('explains API billing and quota failures', async () => {
  await assert.rejects(
    verifyOpenAIAccess({
      ...settings,
      fetchImpl: async () => ({
        ok: false,
        status: 429,
        json: async () => ({ error: { code: 'credit_balance_exhausted' } }),
      }),
    }),
    /billing, credits, or rate limits/u,
  );
});
