import test from 'node:test';
import assert from 'node:assert/strict';
import { spawn } from 'node:child_process';
import { once } from 'node:events';
import { mkdir, mkdtemp, readdir, readFile, rm, stat, writeFile } from 'node:fs/promises';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { fileURLToPath } from 'node:url';

// The two .command files write a Keychain item and a LaunchAgent for real, so they are
// only ever run here inside a sandbox: HOME is a temp folder, and every executable that
// touches the system or the network (security, launchctl, osacompile, open, osascript,
// curl, and node when it is asked to run server.mjs) is a stub found first on PATH.
// The scripts call /usr/bin/security by absolute path; JARVIS_SECURITY_BIN is their
// test-only override and points at the stub. As a backstop the scripts run under a
// macOS seatbelt profile that denies executing the real /usr/bin/security and all
// network access, so a missing override fails loudly instead of reaching the Keychain.
// Each stub appends one line to a call log so the tests can prove call ORDER.
// JARVIS_INSTALLER_DIR points the harness at another copy of the scripts (used to show
// the tests fail against the originals).

const installerDir =
  process.env.JARVIS_INSTALLER_DIR || fileURLToPath(new URL('../..', import.meta.url));
const installScript = join(installerDir, 'Install Jarvis.command');
const uninstallScript = join(installerDir, 'Uninstall Jarvis.command');
const account = 'jarvis-tester';
const openAiService = 'com.imclab.jarvis-demo.openai';
const skip = process.platform === 'darwin' ? false : 'the .command installers are macOS-only';

const seatbelt =
  '(version 1)(allow default)(deny process-exec (literal "/usr/bin/security"))(deny network*)';

const logCall = (name) => `printf '${name} %s\\n' "$*" >> "$JARVIS_TEST_CALL_LOG"\n`;

const stubs = {
  security: `#!/bin/bash
set -eu
${logCall('security')}
cmd=$1; shift
svc=""; acct=""; pw=""; want_pw=0
while [ $# -gt 0 ]; do
  case "$1" in
    -a) acct=$2; shift 2 ;;
    -s) svc=$2; shift 2 ;;
    -w) if [ "$cmd" = add-generic-password ]; then pw=$2; shift 2; else want_pw=1; shift; fi ;;
    *) shift ;;
  esac
done
item="$JARVIS_TEST_KEYCHAIN/$svc@$acct"
case "$cmd" in
  find-generic-password)
    [ -f "$item" ] || { echo "security: item not found" >&2; exit 44; }
    [ "$want_pw" = 1 ] && cat "$item"; exit 0 ;;
  add-generic-password) printf '%s\\n' "$pw" > "$item" ;;
  delete-generic-password) [ -f "$item" ] || exit 44; rm -f "$item" ;;
  *) echo "stub security: unsupported $cmd" >&2; exit 2 ;;
esac
`,
  node: `#!/bin/bash
${logCall('node')}
case "\${1:-}" in *server.mjs) ;; *) exec "$JARVIS_TEST_REAL_NODE" "$@" ;; esac
for arg in "$@"; do
  case "$arg" in
    --self-test) echo "Jarvis MVP self-test passed."; exit 0 ;;
    --check-openai)
      key="\${OPENAI_API_KEY:-}"
      item="$JARVIS_TEST_KEYCHAIN/${openAiService}@$USER"
      [ -n "$key" ] || [ ! -f "$item" ] || key=$(cat "$item")
      printf 'check-openai key=%s\\n' "$key" >> "$JARVIS_TEST_CALL_LOG"
      for valid in $JARVIS_TEST_VALID_KEYS; do
        [ "$key" = "$valid" ] || continue
        echo "OpenAI text (gpt-5.6) and voice (gpt-realtime-2.1) access verified."; exit 0
      done
      echo "OpenAI rejected the API key. Create a new project API key and try again." >&2; exit 1 ;;
  esac
done
echo "stub node: refusing to start the server" >&2; exit 1
`,
  launchctl: `#!/bin/bash\n${logCall('launchctl')}exit 0\n`,
  open: `#!/bin/bash\n${logCall('open')}exit 0\n`,
  osascript: `#!/bin/bash\n${logCall('osascript')}exit 0\n`,
  curl: `#!/bin/bash\n${logCall('curl')}exit 0\n`,
  osacompile: `#!/bin/bash
${logCall('osacompile')}
while [ $# -gt 0 ]; do case "$1" in -o) mkdir -p "$2/Contents"; shift 2 ;; *) shift ;; esac; done
`,
};

async function createSandbox() {
  const root = await mkdtemp(join(tmpdir(), 'jarvis-installer-test-'));
  const home = join(root, 'home');
  const bin = join(root, 'bin');
  const keychain = join(root, 'keychain');
  const callLog = join(root, 'calls.log');
  await mkdir(join(home, '.Trash'), { recursive: true });
  for (const dir of [bin, keychain, join(root, 'tmp')]) await mkdir(dir);
  for (const [name, body] of Object.entries(stubs)) {
    await writeFile(join(bin, name), body, { mode: 0o755 });
  }

  async function run(script, { stdin = '', validKeys = [] } = {}) {
    await writeFile(callLog, '');
    const child = spawn('/usr/bin/sandbox-exec', ['-p', seatbelt, '/bin/bash', script], {
      cwd: root,
      env: {
        PATH: `${bin}:/usr/bin:/bin:/usr/sbin:/sbin`,
        HOME: home,
        TMPDIR: join(root, 'tmp'),
        USER: account,
        JARVIS_SECURITY_BIN: join(bin, 'security'),
        JARVIS_TEST_CALL_LOG: callLog,
        JARVIS_TEST_KEYCHAIN: keychain,
        JARVIS_TEST_REAL_NODE: process.execPath,
        JARVIS_TEST_VALID_KEYS: validKeys.join(' '),
      },
      stdio: ['pipe', 'pipe', 'pipe'],
    });
    let output = '';
    child.stdout.on('data', (chunk) => (output += chunk));
    child.stderr.on('data', (chunk) => (output += chunk));
    child.stdin.end(stdin);
    const [code] = await once(child, 'close');
    const calls = (await readFile(callLog, 'utf8')).split('\n').filter(Boolean);
    return { code, output, calls };
  }

  return {
    home,
    run,
    supportDir: join(home, 'Library', 'Application Support', 'Jarvis Demo'),
    logDir: join(home, 'Library', 'Logs', 'Jarvis Demo'),
    plist: join(home, 'Library', 'LaunchAgents', 'com.imclab.jarvis-demo.plist'),
    storedKey: () =>
      readFile(join(keychain, `${openAiService}@${account}`), 'utf8')
        .then((text) => text.trim())
        .catch(() => null),
    cleanup: () => rm(root, { recursive: true, force: true }),
  };
}

const firstIndex = (calls, prefix) => calls.findIndex((line) => line.startsWith(prefix));
const exists = (path) =>
  stat(path).then(
    () => true,
    () => false,
  );

test(
  'a key that fails the live check is never saved and the installer stops',
  { skip },
  async () => {
    const sandbox = await createSandbox();
    try {
      const { code, output, calls } = await sandbox.run(installScript, { stdin: 'sk-bad\n' });
      assert.notEqual(code, 0, `installer should fail:\n${output}`);
      assert.equal(firstIndex(calls, 'check-openai key=sk-bad') >= 0, true, 'live check ran');
      assert.equal(firstIndex(calls, 'security add-generic-password'), -1, calls.join('\n'));
      assert.equal(await sandbox.storedKey(), null);
      assert.match(output, /not saved/u);
      assert.equal(firstIndex(calls, 'launchctl bootstrap'), -1, 'service must not be installed');
    } finally {
      await sandbox.cleanup();
    }
  },
);

test('a key that passes the live check is saved only after it passes', { skip }, async () => {
  const sandbox = await createSandbox();
  try {
    const { code, output, calls } = await sandbox.run(installScript, {
      stdin: 'sk-good\n',
      validKeys: ['sk-good'],
    });
    assert.equal(code, 0, output);
    const verified = firstIndex(calls, 'check-openai key=sk-good');
    const saved = firstIndex(calls, 'security add-generic-password');
    assert.ok(verified >= 0 && saved >= 0, calls.join('\n'));
    assert.ok(verified < saved, `save must follow verification:\n${calls.join('\n')}`);
    assert.equal(await sandbox.storedKey(), 'sk-good');
    const plist = await readFile(sandbox.plist, 'utf8');
    assert.match(plist, /com\.imclab\.jarvis-demo/u);
    assert.match(plist, /launch\.sh/u, 'the service must start through the boot guard');
    const guard = await readFile(join(sandbox.supportDir, 'launch.sh'), 'utf8');
    assert.match(guard, /--self-test/u);
    assert.match(guard, /mv "\$APP-old" "\$APP"/u, 'guard must roll back to app-old');
    assert.ok(firstIndex(calls, 'launchctl bootstrap') > saved);
    assert.ok(firstIndex(calls, 'open ') > saved);
  } finally {
    await sandbox.cleanup();
  }
});

test('a saved key that still passes is kept by default on re-run', { skip }, async () => {
  const sandbox = await createSandbox();
  try {
    const first = await sandbox.run(installScript, {
      stdin: 'sk-first\n',
      validKeys: ['sk-first'],
    });
    assert.equal(first.code, 0, first.output);
    const rerun = await sandbox.run(installScript, { stdin: '\n', validKeys: ['sk-first'] });
    assert.equal(rerun.code, 0, rerun.output);
    assert.equal(firstIndex(rerun.calls, 'security add-generic-password'), -1);
    assert.equal(await sandbox.storedKey(), 'sk-first');
  } finally {
    await sandbox.cleanup();
  }
});

test('a saved key that stops passing is replaced by default on re-run', { skip }, async () => {
  const sandbox = await createSandbox();
  try {
    const first = await sandbox.run(installScript, {
      stdin: 'sk-first\n',
      validKeys: ['sk-first'],
    });
    assert.equal(first.code, 0, first.output);
    // Return accepts the default answer, then the new key is typed.
    const rerun = await sandbox.run(installScript, {
      stdin: '\nsk-second\n',
      validKeys: ['sk-second'],
    });
    assert.equal(rerun.code, 0, rerun.output);
    assert.match(rerun.output, /no longer passes/u);
    const rejected = firstIndex(rerun.calls, 'check-openai key=sk-first');
    const verified = firstIndex(rerun.calls, 'check-openai key=sk-second');
    const saved = firstIndex(rerun.calls, 'security add-generic-password');
    assert.ok(rejected >= 0 && rejected < verified && verified < saved, rerun.calls.join('\n'));
    assert.equal(rerun.calls.filter((line) => line.startsWith('security add-')).length, 1);
    assert.equal(await sandbox.storedKey(), 'sk-second');
  } finally {
    await sandbox.cleanup();
  }
});

test(
  'uninstall deletes the logs folder and context.json and clears Keychain',
  { skip },
  async () => {
    const sandbox = await createSandbox();
    try {
      const installed = await sandbox.run(installScript, {
        stdin: 'sk-good\n',
        validKeys: ['sk-good'],
      });
      assert.equal(installed.code, 0, installed.output);
      const contextPath = join(sandbox.supportDir, 'context.json');
      await writeFile(contextPath, '{"name":"private.txt","content":"secret"}\n');
      await writeFile(join(sandbox.logDir, 'server.log'), 'log line\n');
      // Everything personal the app can write must go the same way as the source text.
      const personal = ['profile.json', 'usage.jsonl', 'feedback.jsonl'].map((name) =>
        join(sandbox.supportDir, name),
      );
      for (const path of personal) await writeFile(path, '{"name":"Tony"}\n');

      const { code, output, calls } = await sandbox.run(uninstallScript, { stdin: 'y\n' });
      assert.equal(code, 0, output);
      assert.equal(await exists(sandbox.logDir), false, 'logs folder must be deleted');
      assert.equal(await exists(contextPath), false, 'context.json must be deleted');
      for (const path of personal) assert.equal(await exists(path), false, `${path} survived`);
      const leftovers = (await readdir(sandbox.home, { recursive: true })).filter((path) =>
        /context\.json|profile\.json|usage\.jsonl|feedback\.jsonl|Logs\/Jarvis Demo/u.test(path),
      );
      assert.deepEqual(leftovers, [], 'nothing may survive in Trash either');
      assert.equal(await exists(sandbox.supportDir), false);
      assert.equal(await exists(sandbox.plist), false);
      assert.equal(await sandbox.storedKey(), null);
      assert.ok(firstIndex(calls, 'launchctl bootout') >= 0);
      assert.match(output, /logs/iu);
    } finally {
      await sandbox.cleanup();
    }
  },
);
