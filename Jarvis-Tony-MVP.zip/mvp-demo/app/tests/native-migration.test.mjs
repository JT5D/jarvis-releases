import assert from 'node:assert/strict';
import test from 'node:test';
import { parseNativeManifest } from '../native-migration.mjs';

const valid = {
  schemaVersion: '1.0',
  product: 'Jarvis',
  channel: 'executive-preview',
  version: '0.2.0',
  build: 2001,
  commit: 'a'.repeat(40),
  zip: 'https://github.com/JT5D/jarvis-releases/releases/download/native-v0.2.0/Jarvis-0.2.0.app.zip',
  sha256: 'b'.repeat(64),
};

test('native migration accepts only the public native release channel', () => {
  assert.deepEqual(parseNativeManifest(JSON.stringify(valid)), {
    version: '0.2.0',
    build: 2001,
    commit: 'a'.repeat(40),
    zip: valid.zip,
    sha256: valid.sha256,
  });
});

test('native migration rejects an attacker-controlled update URL', () => {
  assert.throws(
    () => parseNativeManifest(JSON.stringify({ ...valid, zip: 'https://evil.example/Jarvis.zip' })),
    /outside the public release repository/u,
  );
});

test('native migration rejects malformed version and checksum metadata', () => {
  assert.throws(
    () => parseNativeManifest(JSON.stringify({ ...valid, version: 'latest' })),
    /version/u,
  );
  assert.throws(
    () => parseNativeManifest(JSON.stringify({ ...valid, sha256: 'bad' })),
    /checksum/u,
  );
});
