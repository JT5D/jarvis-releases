import assert from 'node:assert/strict';
import { generateKeyPairSync, sign } from 'node:crypto';
import { readFileSync } from 'node:fs';
import test from 'node:test';
import {
  chooseInstallTarget,
  checkAndMigrateToNative,
  meetsMinimumMacOS,
  NATIVE_RELEASE_PUBLIC_KEY,
  nativePublicKeyPem,
  parseNativeManifest,
} from '../native-migration.mjs';

const valid = {
  schemaVersion: '1.0',
  product: 'Jarvis',
  channel: 'executive-preview',
  version: '0.2.0',
  build: 2001,
  commit: 'a'.repeat(40),
  zip: 'https://github.com/JT5D/jarvis-releases/releases/download/native-v0.2.0/Jarvis-0.2.0.app.zip',
  sha256: 'b'.repeat(64),
};

test('native migration accepts only the public native release channel', () => {
  assert.deepEqual(parseNativeManifest(JSON.stringify(valid)), {
    version: '0.2.0',
    build: 2001,
    commit: 'a'.repeat(40),
    zip: valid.zip,
    sha256: valid.sha256,
    demoMigrate: false,
    minimumMacOS: '15.0',
  });
});

test('the demo verifies native manifests with the key native Jarvis ships', () => {
  const shipped = readFileSync(
    new URL('../../../apps/macos/Jarvis/Resources/NativeReleaseKey.txt', import.meta.url),
    'utf8',
  ).trim();
  assert.equal(NATIVE_RELEASE_PUBLIC_KEY, shipped);
  assert.match(nativePublicKeyPem(), /^-----BEGIN PUBLIC KEY-----/u);
});

test('macOS minimum comparison', () => {
  assert.equal(meetsMinimumMacOS('15.0', '15.0'), true);
  assert.equal(meetsMinimumMacOS('26.5.1', '15.0'), true);
  assert.equal(meetsMinimumMacOS('14.7.2', '15.0'), false);
  assert.equal(meetsMinimumMacOS('', '15.0'), false);
  assert.equal(meetsMinimumMacOS('garbage', '15.0'), false);
});

test('installs to /Applications, or ~/Applications when that is not writable', async () => {
  assert.equal(
    await chooseInstallTarget({ canWrite: async () => true }),
    '/Applications/Jarvis.app',
  );
  const home = '/private/tmp';
  assert.equal(
    await chooseInstallTarget({ canWrite: async () => false, home }),
    '/private/tmp/Applications/Jarvis.app',
  );
});

test('nothing is downloaded until the manifest enables migration and macOS qualifies', async () => {
  const { privateKey, publicKey } = generateKeyPairSync('ed25519');
  const publicKeyPem = publicKey.export({ type: 'spki', format: 'pem' }).toString();
  const run = async (manifest, osVersion) => {
    const text = JSON.stringify(manifest);
    const requested = [];
    const fetchImpl = async (url) => {
      requested.push(url);
      const body = url.endsWith('.sig')
        ? sign(null, Buffer.from(text), privateKey).toString('base64')
        : text;
      return new Response(body);
    };
    const result = await checkAndMigrateToNative({
      publicKeyPem,
      fetchImpl,
      osVersion: async () => osVersion,
    });
    return { result, requested };
  };
  const off = await run(valid, '26.5');
  assert.deepEqual(off.result, { status: 'not-enabled' });
  assert.equal(off.requested.length, 2, 'only the manifest and its signature');
  const old = await run({ ...valid, demoMigrate: true, minimumMacOS: '15.0' }, '14.6');
  assert.deepEqual(old.result, { status: 'macos-too-old', macOS: '14.6' });
  assert.equal(
    old.requested.some((url) => url.endsWith('.zip')),
    false,
  );
});

test('native migration rejects an attacker-controlled update URL', () => {
  assert.throws(
    () => parseNativeManifest(JSON.stringify({ ...valid, zip: 'https://evil.example/Jarvis.zip' })),
    /outside the public release repository/u,
  );
});

test('native migration rejects malformed version and checksum metadata', () => {
  assert.throws(
    () => parseNativeManifest(JSON.stringify({ ...valid, version: 'latest' })),
    /version/u,
  );
  assert.throws(
    () => parseNativeManifest(JSON.stringify({ ...valid, sha256: 'bad' })),
    /checksum/u,
  );
});
