const elements = Object.fromEntries(
  [
    'account-label',
    'voice-button',
    'voice-label',
    'orb',
    'conversation',
    'composer',
    'message',
    'context-connection',
    'file-input',
    'choose-file',
    'load-demo',
    'selected-source',
    'clear-source',
    'toast',
    'readiness-title',
    'greeting',
    'profile-button',
    'profile-form',
    'profile-name',
    'profile-role',
    'profile-style',
    'profile-voice',
    'profile-memory',
    'profile-vision',
    'profile-reports',
    'reports-notice',
    'reports-ok',
    'reports-off',
    'forget-memory',
    'profile-cancel',
    'send-feedback',
    'suggestion',
    'rating',
    'rating-up',
    'rating-down',
    'rating-note',
    'rating-send',
  ].map((id) => [id, document.getElementById(id)]),
);

const SUGGESTION = 'Summarize this and name the biggest risk.';

let status;
let peerConnection;
let microphoneStream;
let dataChannel;
let remoteAudio;
let voiceSession; // { startedAt, turns, speechStoppedAt } while voice is live
let ratingShown = false;
let chosenRating;
const renderedVoiceItems = new Set();

await refreshStatus();

elements['choose-file'].addEventListener('click', () => elements['file-input'].click());
elements['file-input'].addEventListener('change', attachFile);
elements['load-demo'].addEventListener('click', loadDemo);
elements['clear-source'].addEventListener('click', clearSource);
elements['voice-button'].addEventListener('click', toggleVoice);
elements.composer.addEventListener('submit', sendMessage);
elements['profile-button'].addEventListener('click', () => showProfileForm(true));
elements['profile-cancel'].addEventListener('click', () =>
  elements['profile-form'].classList.add('hidden'),
);
elements['profile-form'].addEventListener('submit', saveProfile);
elements['forget-memory'].addEventListener('click', forgetMemory);
elements['reports-ok'].addEventListener('click', () => acknowledgeReports(true));
elements['reports-off'].addEventListener('click', () => acknowledgeReports(false));
elements['send-feedback'].addEventListener('click', sendFeedback);
elements.suggestion.addEventListener('click', () => {
  elements.message.value = SUGGESTION;
  elements.composer.requestSubmit();
});
elements['rating-up'].addEventListener('click', () => chooseRating('up'));
elements['rating-down'].addEventListener('click', () => chooseRating('down'));
elements['rating-send'].addEventListener('click', saveRating);
window.addEventListener('keydown', (event) => {
  const tag = document.activeElement?.tagName;
  if (event.code === 'Space' && !['INPUT', 'TEXTAREA', 'BUTTON', 'SELECT'].includes(tag)) {
    event.preventDefault();
    toggleVoice();
  }
});
window.addEventListener('beforeunload', stopVoice);

async function refreshStatus() {
  try {
    status = await api('/api/status');
    renderStatus();
  } catch (error) {
    showToast(error.message);
  }
}

function renderStatus() {
  const ready = status.openAiConfigured;
  elements['account-label'].textContent = ready ? 'OpenAI ready' : 'OpenAI key needed';
  document.querySelector('.status-dot').classList.toggle('connected', ready);
  elements['readiness-title'].textContent = ready
    ? 'Ready when you are.'
    : 'OpenAI needs configuration.';
  elements['voice-button'].disabled = !ready;
  renderProfile();
  renderSelectedSource(status.selectedFile);
}

function renderProfile() {
  const profile = status.profile;
  elements['profile-button'].textContent = profile ? profile.name : 'Set up';
  elements.greeting.textContent = profile
    ? `Hi ${profile.name}. Ask me anything, including current news. You can also attach a document. Or press Start voice; your browser asks for the microphone once.`
    : 'Ask anything, or attach a document for questions about it.';
  elements['reports-notice'].classList.toggle('hidden', !profile || profile.reportsNoticeSeen);
  if (!profile) showProfileForm(false);
}

async function acknowledgeReports(enabled) {
  try {
    status = await api('/api/profile', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ ...status.profile, reports: enabled, reportsNoticeSeen: true }),
    });
    renderStatus();
    if (!enabled) showToast('Device health reports are off. You can turn them on in your profile.');
  } catch (error) {
    showToast(error.message);
  }
}

function showProfileForm(cancelable) {
  const profile = status.profile;
  elements['profile-name'].value = profile?.name ?? '';
  elements['profile-role'].value = profile?.role ?? '';
  elements['profile-style'].value = profile?.style ?? 'brief';
  elements['profile-voice'].value = profile?.voice ?? 'marin';
  elements['profile-memory'].checked = profile?.memory !== false;
  elements['profile-vision'].checked = profile?.vision === true;
  elements['profile-reports'].checked = profile?.reports !== false;
  elements['profile-cancel'].classList.toggle('hidden', !cancelable);
  elements['profile-form'].classList.remove('hidden');
  elements['profile-name'].focus();
}

async function forgetMemory() {
  try {
    await api('/api/memory/clear', { method: 'POST' });
    showToast('Saved conversations and observations deleted.');
  } catch (error) {
    showToast(error.message);
  }
}

async function saveProfile(event) {
  event.preventDefault();
  try {
    status = await api('/api/profile', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        name: elements['profile-name'].value,
        role: elements['profile-role'].value,
        style: elements['profile-style'].value,
        voice: elements['profile-voice'].value,
        memory: elements['profile-memory'].checked,
        vision: elements['profile-vision'].checked,
        reports: elements['profile-reports'].checked,
        reportsNoticeSeen: true,
      }),
    });
    elements['profile-form'].classList.add('hidden');
    renderStatus();
    if (peerConnection) {
      stopVoice();
      showToast('Profile saved. Start voice again to use it.');
    }
    if (elements['profile-vision'].checked) await confirmSight();
  } catch (error) {
    showToast(error.message);
  }
}

async function attachFile() {
  const [file] = elements['file-input'].files;
  if (!file) return;
  if (file.size > 50_000) {
    showToast('Choose a text file smaller than 50 KB for this demo.');
    elements['file-input'].value = '';
    return;
  }
  setContextBusy(true);
  try {
    const payload = await api('/api/context', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ name: file.name, mimeType: file.type, content: await file.text() }),
    });
    applySelectedFile(payload.selectedFile);
  } catch (error) {
    showToast(error.message);
  } finally {
    elements['file-input'].value = '';
    setContextBusy(false);
  }
}

async function loadDemo() {
  setContextBusy(true);
  try {
    const payload = await api('/api/context/demo', { method: 'POST' });
    applySelectedFile(payload.selectedFile);
  } catch (error) {
    showToast(error.message);
  } finally {
    setContextBusy(false);
  }
}

function applySelectedFile(file) {
  status.selectedFile = file;
  renderSelectedSource(file);
  if (peerConnection) {
    stopVoice();
    showToast('Context changed. Start voice again to use it.');
  }
}

async function clearSource() {
  try {
    await api('/api/context/clear', { method: 'POST' });
    status.selectedFile = null;
    renderSelectedSource(null);
    stopVoice();
  } catch (error) {
    showToast(error.message);
  }
}

function renderSelectedSource(file) {
  const container = elements['selected-source'];
  const copy = container.querySelector('div');
  copy.replaceChildren();
  const title = document.createElement('strong');
  const note = document.createElement('span');
  title.textContent = file?.name || 'No source selected';
  note.textContent = file
    ? 'Full text is stored locally and restored after restart.'
    : 'Choose a file or use the demo brief.';
  copy.append(title, note);
  container.classList.toggle('has-source', Boolean(file));
  elements['clear-source'].classList.toggle('hidden', !file);
  elements['context-connection'].textContent = file ? 'Source ready' : 'No source';
  elements['context-connection'].classList.toggle('connected', Boolean(file));
  elements.suggestion.textContent = `Try: “${SUGGESTION}”`;
  elements.suggestion.classList.toggle('hidden', !file);
}

function setContextBusy(value) {
  elements['choose-file'].disabled = value;
  elements['load-demo'].disabled = value;
}

async function sendMessage(event) {
  event.preventDefault();
  const message = elements.message.value.trim();
  if (!message) return;
  appendMessage('user', 'You', message);
  elements.message.value = '';
  const pending = appendMessage('assistant', 'Jarvis', 'Thinking…', true);
  setBusy(true);
  const startedAt = performance.now();
  try {
    const payload = await api('/api/chat', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ message }),
    });
    pending.querySelector('p').textContent = payload.answer;
    pending.classList.remove('pending');
    usage({ event: 'turn', kind: 'text', latencyMs: performance.now() - startedAt });
  } catch (error) {
    pending.remove();
    showToast(error.message);
    usage({ event: 'error', code: 'chat' });
  } finally {
    setBusy(false);
  }
}

function appendMessage(role, label, text, pending = false) {
  const article = document.createElement('article');
  article.className = `message ${role}-message${pending ? ' pending' : ''}`;
  const avatar = document.createElement('span');
  avatar.className = `avatar ${role === 'assistant' ? 'jarvis-avatar' : 'user-avatar'}`;
  avatar.textContent =
    role === 'assistant' ? '' : (status?.profile?.name?.[0] ?? 'Y').toUpperCase();
  const body = document.createElement('div');
  const strong = document.createElement('strong');
  strong.textContent = label;
  const paragraph = document.createElement('p');
  paragraph.textContent = text;
  body.append(strong, paragraph);
  article.append(avatar, body);
  elements.conversation.append(article);
  elements.conversation.scrollTop = elements.conversation.scrollHeight;
  return article;
}

function appendVoiceTranscript(role, id, transcript) {
  const text = String(transcript || '').trim();
  if (!text || !id || renderedVoiceItems.has(`${role}:${id}`)) return;
  renderedVoiceItems.add(`${role}:${id}`);
  appendMessage(role, role === 'assistant' ? 'Jarvis' : 'You', text);
}

let voiceGuardTimer;
function startVoiceGuard() {
  clearInterval(voiceGuardTimer);
  voiceGuardTimer = setInterval(() => {
    if (!voiceSession) return;
    const guard = status?.voiceGuard;
    if (!guard) return;
    const now = performance.now();
    const quietFor = now - (voiceSession.lastVoiceAt ?? voiceSession.startedAt);
    const ranFor = now - voiceSession.startedAt;
    if (ranFor >= guard.maxSessionMs) {
      stopVoice();
      showToast('Voice stopped after 30 minutes. Press Start voice to continue.');
    } else if (quietFor >= guard.idleMs) {
      stopVoice();
      showToast('Voice stopped after 3 minutes of silence, so the microphone is not left open.');
    }
  }, 10_000);
}

function configureRealtimeSession() {
  if (dataChannel?.readyState !== 'open') return;
  dataChannel.send(
    JSON.stringify({
      type: 'session.update',
      session: {
        type: 'realtime',
        audio: {
          input: {
            transcription: { model: 'gpt-4o-mini-transcribe' },
            noise_reduction: { type: 'far_field' },
            turn_detection: {
              type: 'server_vad',
              threshold: 0.5,
              prefix_padding_ms: 300,
              silence_duration_ms: 700,
              create_response: false,
              interrupt_response: true,
            },
          },
        },
      },
    }),
  );
}

async function toggleVoice() {
  if (peerConnection) return stopVoice();
  setVoiceState('connecting');
  try {
    peerConnection = new RTCPeerConnection();
    remoteAudio = new Audio();
    remoteAudio.autoplay = true;
    remoteAudio.playsInline = true;
    peerConnection.ontrack = async (event) => {
      remoteAudio.srcObject = event.streams[0] || new MediaStream([event.track]);
      try {
        await remoteAudio.play();
      } catch {
        showToast(
          'Jarvis audio was blocked by the browser. Click the page once, then start voice again.',
        );
      }
    };
    microphoneStream = await navigator.mediaDevices.getUserMedia({
      audio: {
        echoCancellation: true,
        noiseSuppression: true,
        autoGainControl: true,
      },
    });
    peerConnection.addTrack(microphoneStream.getAudioTracks()[0]);
    dataChannel = peerConnection.createDataChannel('oai-events');
    dataChannel.addEventListener('open', () => {
      voiceSession = {
        startedAt: performance.now(),
        turns: 0,
        speechStoppedAt: undefined,
        lastVoiceAt: performance.now(),
      };
      configureRealtimeSession();
      startVoiceGuard();
      usage({ event: 'voice_start' });
      setVoiceState('listening');
    });
    dataChannel.addEventListener('message', handleRealtimeEvent);
    dataChannel.addEventListener('close', () => {
      if (peerConnection) stopVoice();
    });
    dataChannel.addEventListener('error', () => {
      usage({ event: 'error', code: 'realtime_data' });
      showToast('The live voice connection had a problem. Press Start voice to reconnect.');
    });
    const offer = await peerConnection.createOffer();
    await peerConnection.setLocalDescription(offer);
    const answer = await fetch('/api/realtime', {
      method: 'POST',
      headers: { 'Content-Type': 'application/sdp' },
      body: offer.sdp,
    });
    if (!answer.ok) throw new Error((await answer.json()).error || 'Voice connection failed.');
    await peerConnection.setRemoteDescription({ type: 'answer', sdp: await answer.text() });
  } catch (error) {
    stopVoice();
    if (error.name === 'NotAllowedError') {
      usage({ event: 'mic_denied' });
      showToast(
        'Microphone blocked. Click the lock or camera icon in the address bar, allow the microphone for 127.0.0.1, then press Start voice again.',
      );
    } else {
      usage({ event: 'error', code: 'voice_connect' });
      showToast(error.message);
    }
  }
}

function handleRealtimeEvent(event) {
  try {
    const payload = JSON.parse(event.data);
    if (payload.type === 'input_audio_buffer.speech_started') {
      if (voiceSession) voiceSession.lastVoiceAt = performance.now();
      setVoiceState('listening');
    }
    if (payload.type === 'input_audio_buffer.speech_stopped' && voiceSession)
      voiceSession.speechStoppedAt = performance.now();

    if (payload.type === 'input_audio_buffer.committed') sendPerception();
    if (
      payload.type === 'response.function_call_arguments.done' &&
      payload.name === 'get_current_information'
    )
      answerCurrentInformation(payload);

    if (payload.type === 'conversation.item.input_audio_transcription.completed') {
      appendVoiceTranscript('user', payload.item_id, payload.transcript);
    }

    if (payload.type === 'conversation.item.input_audio_transcription.failed') {
      usage({ event: 'error', code: 'voice_transcription' });
      showToast(
        'Jarvis heard the turn, but its transcript could not be displayed. Voice can continue.',
      );
    }

    if (payload.type === 'response.created') setVoiceState('speaking');

    if (payload.type === 'output_audio_buffer.started' && voiceSession) {
      recordVoiceTurn(true);
      remoteAudio?.play().catch(() => {
        showToast(
          'Jarvis audio was blocked by the browser. Click the page once, then start voice again.',
        );
      });
    }

    if (payload.type === 'response.output_audio_transcript.done') {
      appendVoiceTranscript(
        'assistant',
        payload.item_id || payload.response_id,
        payload.transcript,
      );
    }

    if (payload.type === 'response.done') {
      if (voiceSession?.speechStoppedAt !== undefined) recordVoiceTurn(false);
      setVoiceState('listening');
    }

    if (payload.type === 'error') {
      usage({ event: 'error', code: 'realtime' });
      showToast(payload.error?.message || 'Realtime voice error.');
    }
  } catch {
    // Ignore non-JSON WebRTC events.
  }
}

function recordVoiceTurn(withLatency) {
  if (!voiceSession) return;
  const stoppedAt = voiceSession.speechStoppedAt;
  voiceSession.speechStoppedAt = undefined;
  voiceSession.turns += 1;
  const turn = { event: 'turn', kind: 'voice' };
  if (withLatency && stoppedAt !== undefined) turn.latencyMs = performance.now() - stoppedAt;
  usage(turn);
}

function stopVoice() {
  if (voiceSession) {
    usage({
      event: 'voice_end',
      durationMs: performance.now() - voiceSession.startedAt,
      turns: voiceSession.turns,
    });
    if (voiceSession.turns > 0 && !ratingShown) showRating();
    voiceSession = undefined;
  }
  clearInterval(voiceGuardTimer);
  dataChannel?.close();
  peerConnection?.close();
  microphoneStream?.getTracks().forEach((track) => track.stop());
  if (remoteAudio) {
    remoteAudio.pause();
    remoteAudio.srcObject = null;
  }
  dataChannel = undefined;
  peerConnection = undefined;
  microphoneStream = undefined;
  remoteAudio = undefined;
  setVoiceState('idle');
}

function setVoiceState(mode) {
  const labels = {
    idle: 'Start voice',
    connecting: 'Connecting…',
    listening: 'Stop voice',
    speaking: 'Stop voice',
  };
  const headings = {
    idle: status?.openAiConfigured ? 'Ready when you are.' : 'OpenAI needs configuration.',
    connecting: 'Connecting securely…',
    listening: 'Listening…',
    speaking: 'Jarvis is responding…',
  };
  elements['voice-label'].textContent = labels[mode];
  elements['readiness-title'].textContent = headings[mode];
  elements.orb.dataset.state = mode;
  elements['voice-button'].classList.toggle('active', mode !== 'idle');
  elements['voice-button'].disabled = mode === 'connecting' || !status?.openAiConfigured;
}

function showRating() {
  ratingShown = true;
  chosenRating = undefined;
  elements['rating-up'].classList.remove('selected');
  elements['rating-down'].classList.remove('selected');
  elements['rating-note'].value = '';
  elements.rating.classList.remove('hidden');
}

function chooseRating(value) {
  chosenRating = value;
  elements['rating-up'].classList.toggle('selected', value === 'up');
  elements['rating-down'].classList.toggle('selected', value === 'down');
}

async function saveRating() {
  if (!chosenRating) return showToast('Choose thumbs up or thumbs down first.');
  try {
    await api('/api/feedback', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ rating: chosenRating, note: elements['rating-note'].value }),
    });
    elements.rating.classList.add('hidden');
    showToast(
      'Saved on this Mac. Send feedback opens a GitHub issue you review before submitting.',
    );
  } catch (error) {
    showToast(error.message);
  }
}

async function sendFeedback() {
  try {
    const summary = await api('/api/feedback/summary');
    window.open(summary.issueUrl, '_blank', 'noopener');
  } catch (error) {
    showToast(error.message);
  }
}

function usage(event) {
  fetch('/api/usage', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(event),
    keepalive: true,
  }).catch(() => {});
}

function setBusy(value) {
  elements.message.disabled = value;
  elements.composer.querySelector('button').disabled = value;
}

function showToast(message) {
  elements.toast.textContent = message;
  elements.toast.classList.remove('hidden');
  clearTimeout(showToast.timer);
  showToast.timer = setTimeout(() => elements.toast.classList.add('hidden'), 7000);
}

async function confirmSight() {
  try {
    const { status: sightStatus, app } = await api('/api/perception', { method: 'POST' });
    if (sightStatus === 'seeing') {
      usage({ event: 'sight_ready' });
      showToast(`Jarvis can see you are in ${app}.`);
      return;
    }
    usage({ event: 'sight_blocked' });
    showToast(
      'Jarvis could not read your frontmost window. Open System Settings > Privacy & Security > Automation, allow Jarvis to control System Events, then save your profile again.',
    );
  } catch {
    // The profile still saved; a failed check is not worth reporting as a save failure.
  }
}

async function answerCurrentInformation(payload) {
  const channel = dataChannel;
  try {
    const { query } = JSON.parse(payload.arguments);
    const { answer } = await api('/api/chat', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ message: query }),
    });
    if (dataChannel !== channel || channel?.readyState !== 'open') return;
    channel.send(
      JSON.stringify({
        type: 'conversation.item.create',
        item: {
          type: 'function_call_output',
          call_id: payload.call_id,
          output: answer,
        },
      }),
    );
    channel.send(JSON.stringify({ type: 'response.create' }));
  } catch {
    if (dataChannel !== channel || channel?.readyState !== 'open') return;
    channel.send(
      JSON.stringify({
        type: 'conversation.item.create',
        item: {
          type: 'function_call_output',
          call_id: payload.call_id,
          output:
            'Live search failed. Tell the user you cannot verify current news right now. Do not invent headlines.',
        },
      }),
    );
    channel.send(JSON.stringify({ type: 'response.create' }));
  }
}

async function sendPerception() {
  if (dataChannel?.readyState !== 'open') return;
  const channel = dataChannel;
  try {
    const { event } = await api('/api/perception', { method: 'POST' });
    if (!event || dataChannel !== channel || channel.readyState !== 'open') return;
    channel.send(JSON.stringify(event));
    channel.send(JSON.stringify({ type: 'response.create' }));
  } catch {
    if (dataChannel !== channel) return;
    stopVoice();
    showToast(
      'Voice paused because current context could not be refreshed. Press Start voice to reconnect.',
    );
  }
}

async function api(url, options) {
  const response = await fetch(url, options);
  const payload = await response.json();
  if (!response.ok) throw new Error(payload.error || `Request failed (${response.status}).`);
  return payload;
}
