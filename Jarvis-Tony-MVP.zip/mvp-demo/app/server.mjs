import { execFileSync } from 'node:child_process';
import {
  appendFile,
  mkdir,
  open,
  readFile,
  rename,
  stat,
  unlink,
  writeFile,
} from 'node:fs/promises';
import { homedir, release as osRelease } from 'node:os';
import { dirname, extname, join } from 'node:path';
import { fileURLToPath } from 'node:url';
import http from 'node:http';
import { verifyOpenAIAccess } from './openai.mjs';
import { scheduleUpdates } from './update.mjs';
import { readFrontmost } from './vision.mjs';
import {
  ORIGIN,
  PORT,
  VOICES,
  buildInstructions,
  VOICE_IDLE_STOP_MS,
  VOICE_MAX_SESSION_MS,
  formatRecall,
  formatPerception,
  composeChatTurn,
  perceptionEvent,
  shouldRecordActivity,
  newSourceId,
  recallTurns,
  recallActivity,
  parseMemory,
  dropPartialLine,
  MEMORY_TAIL_BYTES,
  createState,
  extractOpenAIText,
  httpError,
  isAllowedOrigin,
  isLoopbackHost,
  normalizeContext,
  parseCookies,
  safetyIdentifier,
  sanitizeFeedback,
  sanitizeProfile,
  sanitizeUsageEvent,
  summarizeUsage,
} from './lib.mjs';

const root = dirname(fileURLToPath(import.meta.url));
const publicRoot = join(root, 'public');
const demoPath = join(root, 'demo', 'Tony-Launch-Brief.txt');
const supportRoot = join(homedir(), 'Library', 'Application Support', 'Jarvis Demo');
const configPath = process.env.JARVIS_CONFIG_PATH || join(supportRoot, 'config.json');
const contextPath = join(dirname(configPath), 'context.json');
const memoryPath = join(dirname(configPath), 'memory.jsonl');
const profilePath = join(dirname(configPath), 'profile.json');
const usagePath = join(dirname(configPath), 'usage.jsonl');
const feedbackPath = join(dirname(configPath), 'feedback.jsonl');
const feedbackRepo = 'https://github.com/JT5D/jarvis';
// release.json is stamped by CI into shipped ZIPs; a checkout has none and never auto-updates.
const release = await loadRelease();
const version =
  release?.version ?? JSON.parse(await readFile(join(root, 'package.json'), 'utf8')).version;
const account = process.env.USER || 'jarvis-demo';
const openAiService = 'com.imclab.jarvis-demo.openai';
const allowedExtensions = new Set([
  '.csv',
  '.html',
  '.json',
  '.log',
  '.md',
  '.txt',
  '.xml',
  '.yaml',
  '.yml',
]);

const config = await loadConfig();
const state = {
  selectedFile: await loadContext(),
  profile: await loadProfile(),
  messages: [],
  // The last thing written to the activity log, so the surprise gate has something to compare to.
  lastActivity: null,
};

if (process.argv.includes('--self-test')) {
  for (const file of ['index.html', 'app.js', 'styles.css']) await stat(join(publicRoot, file));
  await stat(demoPath);
  await stat(join(root, 'release-key.pem'));
  if (Number(process.versions.node.split('.')[0]) < 22) throw new Error('Node 22+ is required.');
  process.stdout.write('Jarvis MVP self-test passed.\n');
  process.exit(0);
}

if (process.argv.includes('--check-openai')) {
  try {
    const verified = await verifyOpenAIAccess({
      apiKey: keychainGet(),
      textModel: config.textModel,
      realtimeModel: config.realtimeModel,
    });
    process.stdout.write(
      `OpenAI text (${verified.textModel}) and voice (${verified.realtimeModel}) access verified.\n`,
    );
    process.exit(0);
  } catch (error) {
    process.stderr.write(`${error.message}\n`);
    process.exit(1);
  }
}

const server = http.createServer(async (request, response) => {
  try {
    if (!isLoopbackHost(request.headers.host))
      return sendText(response, 421, 'Loopback host required.');
    secure(response);
    const url = new URL(request.url || '/', ORIGIN);
    const sessionId = ensureBrowserSession(request, response);

    if (request.method === 'GET' && url.pathname === '/')
      return await serve(response, 'index.html');
    if (request.method === 'GET' && url.pathname === '/app.js')
      return await serve(response, 'app.js');
    if (request.method === 'GET' && url.pathname === '/styles.css')
      return await serve(response, 'styles.css');
    if (request.method === 'GET' && url.pathname === '/api/status')
      return sendJson(response, 200, statusPayload());
    if (request.method === 'GET' && url.pathname === '/api/feedback/summary')
      return sendJson(response, 200, await feedbackSummary());
    if (request.method === 'POST') requireSameOrigin(request);
    if (request.method === 'POST' && url.pathname === '/api/profile') {
      state.profile = sanitizeProfile(await readJson(request, 4_000));
      await saveJson(profilePath, state.profile);
      return sendJson(response, 200, statusPayload());
    }
    if (request.method === 'POST' && url.pathname === '/api/usage') {
      const event = sanitizeUsageEvent(await readJson(request, 4_000));
      if (!event) throw httpError(400, 'Unknown usage event.');
      await appendLine(usagePath, event);
      return sendJson(response, 200, { ok: true });
    }
    if (request.method === 'POST' && url.pathname === '/api/feedback') {
      await appendLine(feedbackPath, sanitizeFeedback(await readJson(request, 4_000)));
      return sendJson(response, 200, { ok: true });
    }
    if (request.method === 'POST' && url.pathname === '/api/context') {
      const body = await readJson(request, 80_000);
      return await selectLocalContext(body, response);
    }
    if (request.method === 'POST' && url.pathname === '/api/context/demo')
      return await selectDemoContext(response);
    // POST, not GET, so the same-origin check above applies: a window title says more about a
    // person than /api/status does, and it should not be readable by a page that merely knows the
    // port. Returns null when sight is off, and the spoken-blindness sentence when the read failed.
    if (request.method === 'POST' && url.pathname === '/api/perception') {
      if (state.profile?.vision !== true)
        return sendJson(response, 200, {
          event: perceptionEvent(null, buildInstructions(state.selectedFile, state.profile)),
          status: 'off',
        });
      const view = await observe();
      // `status` exists so the UI can tell the two silences apart. Both produce honest answers, but
      // only one is fixable by the person, and they cannot fix what they were never told about.
      return sendJson(response, 200, {
        event: perceptionEvent(
          formatPerception(view),
          buildInstructions(state.selectedFile, state.profile),
        ),
        status: view ? 'seeing' : 'blocked',
        app: view?.app ?? null,
      });
    }
    if (request.method === 'POST' && url.pathname === '/api/memory/clear') {
      await unlink(memoryPath).catch((error) => {
        if (error?.code !== 'ENOENT') throw error;
      });
      return sendJson(response, 200, { ok: true });
    }
    if (request.method === 'POST' && url.pathname === '/api/context/clear')
      return await clearContext(response);
    if (request.method === 'POST' && url.pathname === '/api/chat') {
      const body = await readJson(request);
      return await chat(body.message, response, sessionId);
    }
    if (request.method === 'POST' && url.pathname === '/api/realtime')
      return await createRealtimeCall(request, response, sessionId);
    return sendJson(response, 404, { error: 'Not found.' });
  } catch (error) {
    const code = Number(error?.statusCode) || 500;
    if (code >= 500) process.stderr.write(`${new Date().toISOString()} ${error?.stack || error}\n`);
    return sendJson(response, code, {
      error: error?.expose ? error.message : 'Jarvis could not complete that request.',
    });
  }
});

// Nothing after the port is open may take the process down with it. This callback is async and
// nobody awaits it, so a rejection here is an unhandled one, and launchd's KeepAlive turns that
// into a restart loop rather than a crash you would notice. Worse, arming the updater is the last
// thing this function does: a throw above it takes out the very mechanism that ships the fix, and
// the machine can never be repaired remotely again. An assistant that runs without auto-update is
// a bad day; one that cannot be updated is a brick, so failing here degrades instead of exiting.
server.listen(PORT, '127.0.0.1', async () => {
  process.stdout.write(`Jarvis MVP is ready at ${ORIGIN}\n`);
  if (!release || process.env.JARVIS_UPDATES === 'off') {
    process.stdout.write('Auto-update is off (development build or JARVIS_UPDATES=off).\n');
    return;
  }
  try {
    scheduleUpdates({
      currentVersion: release.version,
      appDir: root,
      publicKeyPem: await readFile(join(root, 'release-key.pem'), 'utf8'),
      log: (line) => process.stdout.write(`${new Date().toISOString()} update: ${line}\n`),
    });
  } catch (error) {
    // Said plainly, because this is the one failure a person cannot discover by using the app: it
    // keeps answering exactly as before, and simply stops receiving fixes.
    process.stderr.write(
      `${new Date().toISOString()} Auto-update could not start, so this copy will not receive fixes: ${error.message}\n`,
    );
  }
});

async function loadRelease() {
  try {
    const value = JSON.parse(await readFile(join(root, 'release.json'), 'utf8'));
    return /^tony-mvp-v\d+$/u.test(value?.version) ? { version: value.version } : null;
  } catch (error) {
    if (error?.code !== 'ENOENT') throw error;
    return null;
  }
}

async function loadConfig() {
  try {
    const parsed = JSON.parse(await readFile(configPath, 'utf8'));
    return {
      textModel: String(parsed.textModel || 'gpt-5.6'),
      realtimeModel: String(parsed.realtimeModel || 'gpt-realtime-2.1'),
    };
  } catch (error) {
    if (error?.code !== 'ENOENT') throw error;
    return {
      textModel: process.env.OPENAI_TEXT_MODEL || 'gpt-5.6',
      realtimeModel: process.env.OPENAI_REALTIME_MODEL || 'gpt-realtime-2.1',
    };
  }
}

// Long-term memory is an append-only JSONL of past turns. A corrupt or half-written line is
// skipped rather than thrown: memory is a convenience, and losing it must never stop a turn.
//
// Only the tail is read. The log never shrinks, so reading it whole made every turn a little more
// expensive than the last -- unbounded work to use a bounded amount of it.
async function loadMemory() {
  let handle;
  try {
    handle = await open(memoryPath, 'r');
    const { size } = await handle.stat();
    const start = Math.max(0, size - MEMORY_TAIL_BYTES);
    const buffer = Buffer.alloc(size - start);
    await handle.read(buffer, 0, buffer.length, start);
    const text = buffer.toString('utf8');
    return parseMemory(start > 0 ? dropPartialLine(text) : text);
  } catch (error) {
    if (error?.code !== 'ENOENT')
      process.stderr.write(`${new Date().toISOString()} Memory read skipped: ${error.message}\n`);
    return [];
  } finally {
    await handle?.close();
  }
}

/**
 * Read what they are working in, and write it down when it changed.
 *
 * Grounding a single answer is the smallest thing perception is for. The larger one is that Jarvis
 * can later say what you were doing on Tuesday -- which is the thing a chat assistant that sees
 * your screen for one turn and forgets it structurally cannot do. Dated observations do not go
 * stale; they become history.
 *
 * Writing is gated on remembering as well as sight: this lands in the same log, under the same
 * switch and the same Forget everything button.
 */
async function observe() {
  const view = await readFrontmost();
  if (!view || state.profile?.memory === false) return view;
  const now = Date.now();
  if (!shouldRecordActivity(state.lastActivity, view, now)) return view;
  state.lastActivity = { ...view, t: now };
  try {
    await appendFile(
      memoryPath,
      `${JSON.stringify({ t: now, app: view.app, window: view.window })}\n`,
      {
        mode: 0o600,
      },
    );
  } catch (error) {
    process.stderr.write(`${new Date().toISOString()} Activity write skipped: ${error.message}\n`);
  }
  return view;
}

async function rememberTurn(question, answer) {
  try {
    await appendFile(
      memoryPath,
      `${JSON.stringify({ t: Date.now(), q: question.slice(0, 1_000), a: answer.slice(0, 2_000) })}\n`,
      { mode: 0o600 },
    );
  } catch (error) {
    process.stderr.write(`${new Date().toISOString()} Memory write skipped: ${error.message}\n`);
  }
}

async function loadContext() {
  try {
    const value = JSON.parse(await readFile(contextPath, 'utf8'));
    if (!value?.name || !value?.content) return null;
    return {
      name: String(value.name).slice(0, 160),
      mimeType: String(value.mimeType || 'text/plain').slice(0, 120),
      content: normalizeContext(value.content),
      sourceId: String(value.sourceId || '').match(/^[0-9a-f]{24}$/u)?.[0] || newSourceId(),
    };
  } catch (error) {
    if (error?.code !== 'ENOENT')
      process.stderr.write(
        `${new Date().toISOString()} Context restore skipped: ${error.message}\n`,
      );
    return null;
  }
}

async function loadProfile() {
  try {
    return sanitizeProfile(JSON.parse(await readFile(profilePath, 'utf8')));
  } catch (error) {
    if (error?.code !== 'ENOENT')
      process.stderr.write(
        `${new Date().toISOString()} Profile restore skipped: ${error.message}\n`,
      );
    return null;
  }
}

async function saveJson(path, value) {
  await mkdir(dirname(path), { recursive: true, mode: 0o700 });
  const temporary = `${path}.tmp`;
  await writeFile(temporary, `${JSON.stringify(value, null, 2)}\n`, { mode: 0o600 });
  await rename(temporary, path);
}

// One JSON object per line, stamped here so a client cannot forge the time. Owner-only file.
async function appendLine(path, value) {
  await mkdir(dirname(path), { recursive: true, mode: 0o700 });
  await appendFile(path, `${JSON.stringify({ at: new Date().toISOString(), ...value })}\n`, {
    mode: 0o600,
  });
}

async function readLines(path) {
  try {
    return (await readFile(path, 'utf8'))
      .split('\n')
      .filter(Boolean)
      .flatMap((line) => {
        try {
          return [JSON.parse(line)];
        } catch {
          return [];
        }
      });
  } catch (error) {
    if (error?.code !== 'ENOENT') throw error;
    return [];
  }
}

// Counts and timings from the last seven days plus the latest rating, and a GitHub issue URL
// prefilled with exactly that. Nothing leaves the Mac until the user submits the issue there.
async function feedbackSummary() {
  const since = Date.now() - 7 * 86_400_000;
  const recent = (items) => items.filter((item) => Date.parse(item.at) >= since);
  const usage = summarizeUsage(recent(await readLines(usagePath)));
  const lastFeedback = (await readLines(feedbackPath)).at(-1) ?? null;
  const who = state.profile?.name || 'a user';
  const rating = lastFeedback ? (lastFeedback.rating === 'up' ? '👍' : '👎') : 'no rating yet';
  const body = [
    `**From:** ${who} · Jarvis Tony MVP v${version} · ${process.platform} ${osRelease()} · Node ${process.versions.node}`,
    `**Models:** ${config.textModel} · ${config.realtimeModel} · voice ${state.profile?.voice || 'marin'}`,
    '',
    `**Last 7 days:** ${usage.voiceSessions} voice sessions · ${usage.voiceTurns} voice turns · ${usage.textTurns} text turns · ${usage.errors} errors · ${usage.micDenied} mic denials`,
    `**Voice latency (end of speech → first audio):** p50 ${formatMs(usage.latency.p50Ms)} · p95 ${formatMs(usage.latency.p95Ms)} · n=${usage.latency.samples}`,
    '',
    `**Rating:** ${rating}`,
    lastFeedback?.note ? `**Note:** ${lastFeedback.note}` : '**Note:** (none)',
    '',
    '_Counts and timings only. No message or document text is included._',
  ].join('\n');
  const params = new URLSearchParams({
    title: `Demo feedback from ${who}: ${rating}`,
    body,
    labels: 'demo-feedback',
  });
  return { days: 7, ...usage, lastFeedback, issueUrl: `${feedbackRepo}/issues/new?${params}` };
}

function formatMs(value) {
  return value == null ? 'n/a' : `${value} ms`;
}

function keychainGet() {
  if (process.env.OPENAI_API_KEY) return process.env.OPENAI_API_KEY;
  if (process.platform !== 'darwin') return '';
  try {
    return execFileSync(
      '/usr/bin/security',
      ['find-generic-password', '-a', account, '-s', openAiService, '-w'],
      { encoding: 'utf8', stdio: ['ignore', 'pipe', 'ignore'] },
    ).trim();
  } catch {
    return '';
  }
}

function ensureBrowserSession(request, response) {
  const cookies = parseCookies(request.headers.cookie);
  const existing = cookies.jarvis_session;
  if (existing && /^[A-Za-z0-9_-]{32,128}$/u.test(existing)) return existing;
  const value = createState();
  response.setHeader(
    'Set-Cookie',
    `jarvis_session=${value}; HttpOnly; SameSite=Strict; Path=/; Max-Age=86400`,
  );
  return value;
}

function secure(response) {
  response.setHeader('Cache-Control', 'no-store');
  response.setHeader(
    'Content-Security-Policy',
    "default-src 'self'; script-src 'self'; style-src 'self'; img-src 'self' data:; connect-src 'self'; media-src 'self' blob:; object-src 'none'; base-uri 'none'; frame-ancestors 'none'; form-action 'self'",
  );
  response.setHeader('Referrer-Policy', 'no-referrer');
  response.setHeader('X-Content-Type-Options', 'nosniff');
  response.setHeader('X-Frame-Options', 'DENY');
}

function requireSameOrigin(request) {
  if (!isAllowedOrigin(request.headers.origin)) throw httpError(403, 'Origin rejected.');
}

function statusPayload() {
  return {
    ready: true,
    version,
    openAiConfigured: Boolean(keychainGet()),
    profile: state.profile,
    // The browser enforces these; lib.mjs owns the numbers so they cannot drift between the two.
    voiceGuard: { idleMs: VOICE_IDLE_STOP_MS, maxSessionMs: VOICE_MAX_SESSION_MS },
    voices: VOICES,
    selectedFile: summarizeSelectedFile(),
    models: { text: config.textModel, realtime: config.realtimeModel },
  };
}

function summarizeSelectedFile() {
  return state.selectedFile
    ? {
        name: state.selectedFile.name,
        mimeType: state.selectedFile.mimeType,
        contextAvailable: Boolean(state.selectedFile.content),
      }
    : null;
}

async function selectLocalContext(body, response) {
  const name = String(body.name || '')
    .trim()
    .slice(0, 160);
  const mimeType = String(body.mimeType || 'text/plain')
    .trim()
    .slice(0, 120);
  const extension = extname(name).toLowerCase();
  if (!name || !allowedExtensions.has(extension))
    throw httpError(400, 'Choose a TXT, Markdown, CSV, JSON, XML, YAML, HTML, or log file.');
  const content = normalizeContext(body.content);
  if (!content) throw httpError(400, 'That file has no readable text.');
  state.selectedFile = { name, mimeType, content, sourceId: newSourceId() };
  state.messages = [];
  await saveJson(contextPath, state.selectedFile);
  return sendJson(response, 200, { selectedFile: summarizeSelectedFile() });
}

async function selectDemoContext(response) {
  state.selectedFile = {
    name: 'Tony Launch Brief.txt',
    mimeType: 'text/plain',
    content: normalizeContext(await readFile(demoPath, 'utf8')),
    sourceId: newSourceId(),
  };
  state.messages = [];
  await saveJson(contextPath, state.selectedFile);
  return sendJson(response, 200, { selectedFile: summarizeSelectedFile() });
}

async function clearContext(response) {
  state.selectedFile = null;
  state.messages = [];
  await unlink(contextPath).catch((error) => {
    if (error?.code !== 'ENOENT') throw error;
  });
  return sendJson(response, 200, statusPayload());
}

async function chat(message, response, sessionId) {
  const clean = String(message || '').trim();
  if (!clean || clean.length > 4_000)
    throw httpError(400, 'Enter a message between 1 and 4,000 characters.');
  const apiKey = keychainGet();
  if (!apiKey) throw httpError(503, 'OpenAI is not configured. Re-run the installer.');
  // Recall goes in `input`, never in `instructions`: the instructions carry the document and must
  // stay byte-identical across turns for OpenAI's prompt cache to hit. Anything that varies per
  // question belongs after that prefix.
  const remembering = state.profile?.memory !== false;
  const remembered = remembering ? await loadMemory() : [];
  // Two ways in: by what was said, and by when. A question about a topic finds matching turns; a
  // question about yesterday finds what they had open, which no term-frequency ranker can reach.
  const recalled = remembering
    ? formatRecall([...recallTurns(clean, remembered), ...recallActivity(clean, remembered)])
    : null;
  // What is in front of them is true for this turn only, so it rides along with the question and is
  // never stored. Replayed next turn it would be a confident lie about where they are now.
  const seeing = formatPerception(state.profile?.vision === true ? await observe() : null);
  const turn = composeChatTurn({
    recalled,
    seeing,
    priorMessages: state.messages.slice(-8),
    question: clean,
  });
  const providerResponse = await fetch('https://api.openai.com/v1/responses', {
    method: 'POST',
    headers: {
      Authorization: `Bearer ${apiKey}`,
      'Content-Type': 'application/json',
      'OpenAI-Safety-Identifier': safetyIdentifier(sessionId),
    },
    body: JSON.stringify({
      model: config.textModel,
      instructions: buildInstructions(state.selectedFile, state.profile),
      input: turn.input,
      tools: [{ type: 'web_search' }],
      max_output_tokens: 900,
      store: false,
    }),
    signal: AbortSignal.timeout(60_000),
  });
  const payload = await providerResponse.json();
  if (!providerResponse.ok)
    throw httpError(
      502,
      `OpenAI text request failed (${payload?.error?.code || providerResponse.status}). Re-run the installer to check the key and API billing.`,
    );
  const answer = extractOpenAIText(payload);
  if (!answer) throw httpError(502, 'OpenAI returned no text.');
  state.messages = [...turn.stored, { role: 'assistant', content: answer }].slice(-10);
  if (remembering) await rememberTurn(clean, answer);
  return sendJson(response, 200, { answer });
}

async function createRealtimeCall(request, response, sessionId) {
  const apiKey = keychainGet();
  if (!apiKey) throw httpError(503, 'OpenAI is not configured. Re-run the installer.');
  const sdp = await readText(request, 128_000);
  if (!sdp.startsWith('v=0')) throw httpError(400, 'Invalid WebRTC offer.');
  const form = new FormData();
  form.set('sdp', sdp);
  form.set(
    'session',
    JSON.stringify({
      type: 'realtime',
      model: config.realtimeModel,
      instructions: `${buildInstructions(state.selectedFile, state.profile)}\n\n${formatPerception(null)}`,
      tools: [
        {
          type: 'function',
          name: 'get_current_information',
          description:
            'Search the live web for news and other current facts. Use for today, latest, recent news, or facts that may have changed.',
          parameters: {
            type: 'object',
            properties: { query: { type: 'string' } },
            required: ['query'],
            additionalProperties: false,
          },
        },
      ],
      audio: {
        input: { turn_detection: { type: 'server_vad', create_response: false } },
        output: { voice: state.profile?.voice || 'marin' },
      },
    }),
  );
  const providerResponse = await fetch('https://api.openai.com/v1/realtime/calls', {
    method: 'POST',
    headers: {
      Authorization: `Bearer ${apiKey}`,
      'OpenAI-Safety-Identifier': safetyIdentifier(sessionId),
    },
    body: form,
    signal: AbortSignal.timeout(30_000),
  });
  const answerSdp = await providerResponse.text();
  if (!providerResponse.ok) {
    throw httpError(
      502,
      `OpenAI Realtime failed (${providerResponse.status}). Re-run the installer to check voice access.`,
    );
  }
  response.writeHead(200, { 'Content-Type': 'application/sdp' });
  response.end(answerSdp);
}

async function serve(response, filename) {
  const body = await readFile(join(publicRoot, filename));
  const types = {
    '.html': 'text/html; charset=utf-8',
    '.js': 'text/javascript; charset=utf-8',
    '.css': 'text/css; charset=utf-8',
  };
  response.writeHead(200, {
    'Content-Type': types[extname(filename)] || 'application/octet-stream',
  });
  response.end(body);
}

async function readJson(request, limit = 64_000) {
  const raw = await readText(request, limit);
  try {
    return JSON.parse(raw || '{}');
  } catch {
    throw httpError(400, 'Invalid JSON.');
  }
}

async function readText(request, limit) {
  const chunks = [];
  let size = 0;
  for await (const chunk of request) {
    size += chunk.length;
    if (size > limit) throw httpError(413, 'Request is too large.');
    chunks.push(chunk);
  }
  return Buffer.concat(chunks).toString('utf8');
}

function sendJson(response, status, value) {
  response.writeHead(status, { 'Content-Type': 'application/json; charset=utf-8' });
  response.end(JSON.stringify(value));
}

function sendText(response, status, value) {
  response.writeHead(status, { 'Content-Type': 'text/plain; charset=utf-8' });
  response.end(value);
}
