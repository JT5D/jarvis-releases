import { execFile } from 'node:child_process';

// Reading the frontmost window costs one osascript round trip. Measured on an M3 Max: 170ms warm,
// 370ms cold. The timeout is well above both so a slow read degrades to blindness rather than
// holding up the answer -- a late reply is worse than an honest "I cannot see".
export const PERCEPTION_TIMEOUT_MS = 1_500;

// System Events reports the frontmost process and, when it has one, its front window's title.
// `try` around the window keeps apps with no window (menu bar agents, full screen video) returning
// the app name rather than failing the whole read.
const SCRIPT = `tell application "System Events"
  set procName to name of first application process whose frontmost is true
  set winName to ""
  try
    set winName to name of front window of (first application process whose frontmost is true)
  end try
end tell
return procName & "\\n" & winName`;

function runOsascript(timeoutMs) {
  return new Promise((resolve) => {
    execFile('osascript', ['-e', SCRIPT], { timeout: timeoutMs }, (error, stdout) => {
      resolve(error ? null : String(stdout));
    });
  });
}

/**
 * The frontmost app and window title, or null when that could not be read.
 *
 * Null is a normal outcome, not an error: the person may never have granted Automation access, the
 * read may time out, or nothing may be frontmost. Every one of those means the same thing to the
 * caller -- Jarvis cannot see -- and that is said out loud rather than papered over.
 */
export async function readFrontmost({
  run = runOsascript,
  timeoutMs = PERCEPTION_TIMEOUT_MS,
} = {}) {
  const raw = await run(timeoutMs);
  if (!raw) return null;
  const [app = '', window = ''] = String(raw).split('\n');
  if (!app.trim()) return null;
  return { app: app.trim(), window: window.trim() };
}
