// Auto-update for installed copies. CI publishes a signed manifest to the public releases repo;
// this module verifies the Ed25519 signature with the key shipped in the app, checks the ZIP's
// sha256, unpacks beside the live app, and swaps directories atomically. The previous app is
// kept at <app>-old so the launcher can roll back if the new build fails its self-test.
import { execFile } from 'node:child_process';
import { createHash, createPublicKey, verify } from 'node:crypto';
import { readFile, rename, rm, stat, writeFile } from 'node:fs/promises';
import { join } from 'node:path';
import { promisify } from 'node:util';

export const MANIFEST_URL =
  'https://raw.githubusercontent.com/JT5D/jarvis-releases/main/manifest.json';
export const ALLOWED_ZIP_PREFIX = 'https://raw.githubusercontent.com/JT5D/jarvis-releases/';
const execFileAsync = promisify(execFile);

export function parseVersion(tag) {
  const match = /^tony-mvp-v(\d+)$/u.exec(String(tag ?? ''));
  return match ? Number(match[1]) : NaN;
}

export function verifyManifest(manifestText, signatureBase64, publicKeyPem) {
  try {
    return verify(
      null,
      Buffer.from(manifestText),
      createPublicKey(publicKeyPem),
      Buffer.from(String(signatureBase64).trim(), 'base64'),
    );
  } catch {
    return false;
  }
}

export function parseManifest(text, { allowedZipPrefix = ALLOWED_ZIP_PREFIX } = {}) {
  const value = JSON.parse(text);
  const number = parseVersion(value.version);
  if (!Number.isFinite(number)) throw new Error('manifest version is not a release tag');
  if (typeof value.zip !== 'string' || !value.zip.startsWith(allowedZipPrefix))
    throw new Error('manifest zip URL is outside the releases repo');
  if (!/^[0-9a-f]{64}$/u.test(String(value.sha256 ?? '')))
    throw new Error('manifest sha256 is malformed');
  return { version: value.version, number, zip: value.zip, sha256: value.sha256 };
}

export async function checkForUpdate({
  manifestUrl = MANIFEST_URL,
  allowedZipPrefix = ALLOWED_ZIP_PREFIX,
  publicKeyPem,
  currentVersion,
  appDir,
  fetchImpl = fetch,
  log = () => {},
}) {
  const [manifestText, signature] = await Promise.all([
    fetchText(fetchImpl, manifestUrl),
    fetchText(fetchImpl, `${manifestUrl}.sig`),
  ]);
  if (!verifyManifest(manifestText, signature, publicKeyPem)) {
    log('manifest signature invalid; ignoring');
    return { status: 'bad-signature' };
  }
  const manifest = parseManifest(manifestText, { allowedZipPrefix });
  if (!(manifest.number > parseVersion(currentVersion)))
    return { status: 'current', version: currentVersion };

  log(`downloading ${manifest.version}`);
  const zipPath = `${appDir}-update.zip`;
  const stagePath = `${appDir}-new`;
  const oldPath = `${appDir}-old`;
  await rm(zipPath, { force: true });
  await rm(stagePath, { recursive: true, force: true });
  try {
    const response = await fetchImpl(manifest.zip, { cache: 'no-store' });
    if (!response.ok) throw new Error(`download failed (${response.status})`);
    const bytes = Buffer.from(await response.arrayBuffer());
    if (createHash('sha256').update(bytes).digest('hex') !== manifest.sha256) {
      log('checksum mismatch; ignoring');
      return { status: 'bad-checksum' };
    }
    await writeFile(zipPath, bytes, { mode: 0o600 });
    await execFileAsync('/usr/bin/ditto', ['-x', '-k', zipPath, stagePath]);
    const candidate = join(stagePath, 'mvp-demo', 'app');
    const release = JSON.parse(await readFile(join(candidate, 'release.json'), 'utf8'));
    if (release.version !== manifest.version) {
      log('release.json inside the zip does not match the manifest; ignoring');
      return { status: 'mismatch' };
    }
    await stat(join(candidate, 'server.mjs'));
    await rm(oldPath, { recursive: true, force: true });
    await rename(appDir, oldPath);
    await rename(candidate, appDir);
    log(`updated to ${manifest.version}; previous app kept at ${oldPath}`);
    return { status: 'updated', version: manifest.version };
  } finally {
    await rm(zipPath, { force: true });
    await rm(stagePath, { recursive: true, force: true });
  }
}

// First check shortly after boot, then every six hours. After a successful swap the process
// exits and launchd (KeepAlive) starts the new code through the launcher's boot guard.
export function scheduleUpdates({
  initialDelayMs = 30_000,
  intervalMs = 6 * 3_600_000,
  onUpdated = () => process.exit(0),
  ...options
}) {
  let running = false;
  const tick = async () => {
    if (running) return;
    running = true;
    try {
      const result = await checkForUpdate(options);
      if (result.status === 'updated') onUpdated(result);
    } catch (error) {
      options.log?.(`check failed: ${error.message}`);
    } finally {
      running = false;
    }
  };
  setTimeout(tick, initialDelayMs).unref();
  setInterval(tick, intervalMs).unref();
}

async function fetchText(fetchImpl, url) {
  const response = await fetchImpl(url, { cache: 'no-store' });
  if (!response.ok) throw new Error(`${url} answered ${response.status}`);
  return response.text();
}
