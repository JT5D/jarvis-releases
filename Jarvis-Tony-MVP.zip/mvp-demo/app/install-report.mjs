// Install health for the admin, never content. The demo posts to the same Apps Script sink as the
// native app with exactly the keys in apps/install-report/fields.json (tests enforce both), so the
// admin's Sheet shows which Macs are still on the demo and whether their macOS can run native Jarvis.
// What Node cannot sense (Apple Intelligence, permissions, wake timings) is sent as "unknown".
import { execFile } from 'node:child_process';
import { randomUUID } from 'node:crypto';
import { mkdir, readFile, writeFile } from 'node:fs/promises';
import { totalmem } from 'node:os';
import { join } from 'node:path';
import { promisify } from 'node:util';

const execFileAsync = promisify(execFile);

export const REPORT_URL =
  'https://script.google.com/macros/s/AKfycbwLuMLiCstheduipIu_SDSgUIyOVeR9Ayhge01hnzz5urk0FITsm9lh_w7VBAzCxEZMhw/exec';

export const FIELDS = [
  'installId',
  'channel',
  'reason',
  'reportedAt',
  'appVersion',
  'appBuild',
  'latestBuildSeen',
  'updateResult',
  'updateCheckedAt',
  'macOSVersion',
  'macModel',
  'chip',
  'memoryGB',
  'appleIntelligence',
  'onDeviceSpeech',
  'microphone',
  'speechRecognition',
  'screenRecording',
  'accessibility',
  'loginItem',
  'wakeWord',
  'openAIKeyStored',
  'launches',
  'uncleanExits',
  'lastError',
  'locale',
  'lowPowerMode',
  'loginToArmedMs',
  'wakeToReadyP50Ms',
  'speechEndToFirstAudioP50Ms',
  'speechEndToFirstAudioP95Ms',
  'residentMemoryMB',
];

export function buildReport({
  installId,
  reason,
  version,
  launches,
  openAIKeyStored,
  update = {},
  host = {},
  now = new Date(),
}) {
  const build = Number(/^tony-mvp-v(\d+)$/u.exec(String(version))?.[1]);
  const values = {
    installId,
    channel: 'demo',
    reason,
    reportedAt: now.toISOString(),
    appVersion: version,
    appBuild: Number.isFinite(build) ? build : undefined,
    latestBuildSeen: update.latestBuild,
    updateResult: update.result,
    updateCheckedAt: update.checkedAt,
    ...host,
    openAIKeyStored,
    launches,
    lastError: 'none',
  };
  return Object.fromEntries(FIELDS.map((field) => [field, values[field] ?? 'unknown']));
}

export async function senseHost(run = runCommand) {
  const [macOSVersion, macModel, chip, power] = await Promise.all([
    run('/usr/bin/sw_vers', ['-productVersion']),
    run('/usr/sbin/sysctl', ['-n', 'hw.model']),
    run('/usr/sbin/sysctl', ['-n', 'machdep.cpu.brand_string']),
    run('/usr/bin/pmset', ['-g']),
  ]);
  const lowPower = /lowpowermode\s+(\d)/u.exec(power ?? '')?.[1];
  return {
    macOSVersion,
    macModel,
    chip,
    memoryGB: Math.round(totalmem() / 1_073_741_824),
    locale: Intl.DateTimeFormat().resolvedOptions().locale,
    lowPowerMode: lowPower === undefined ? undefined : lowPower === '1',
    residentMemoryMB: Math.round(process.memoryUsage().rss / 1_048_576),
  };
}

/** Counts launches and keeps one random install ID per Mac; native Jarvis adopts it on migration. */
export async function recordLaunch(supportRoot) {
  const path = join(supportRoot, 'install-report-state.json');
  let state = {};
  try {
    state = JSON.parse(await readFile(path, 'utf8'));
  } catch {
    // First launch, or an unreadable file: start a fresh record.
  }
  const next = {
    installId: /^[0-9a-f-]{36}$/u.test(String(state.installId)) ? state.installId : randomUUID(),
    launches: (Number.isInteger(state.launches) ? state.launches : 0) + 1,
  };
  await mkdir(supportRoot, { recursive: true, mode: 0o700 });
  await writeFile(path, `${JSON.stringify(next)}\n`, { mode: 0o600 });
  return next;
}

export function scheduleInstallReports({
  supportRoot,
  version,
  launch,
  enabled,
  openAIKeyStored,
  update,
  fetchImpl = fetch,
  sense = senseHost,
  log = () => {},
  url = REPORT_URL,
  initialDelayMs = 45_000,
  intervalMs = 24 * 3_600_000,
}) {
  const send = async (reason) => {
    try {
      const report = buildReport({
        installId: launch.installId,
        launches: launch.launches,
        reason,
        version,
        openAIKeyStored: openAIKeyStored(),
        update: update(),
        host: await sense(),
      });
      await writeFile(join(supportRoot, 'install-report.json'), `${JSON.stringify(report)}\n`, {
        mode: 0o600,
      });
      if (!enabled()) return 'off';
      const response = await fetchImpl(url, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(report),
        signal: AbortSignal.timeout(20_000),
      });
      log(`install report ${reason}: ${response.status}`);
      return 'sent';
    } catch (error) {
      log(`install report ${reason} failed: ${error.message}`);
      return 'failed';
    }
  };
  let reason = 'launch';
  const tick = async () => {
    await send(reason);
    reason = 'daily';
  };
  setTimeout(tick, initialDelayMs).unref();
  setInterval(tick, intervalMs).unref();
  return send;
}

async function runCommand(file, args) {
  try {
    const { stdout } = await execFileAsync(file, args, { timeout: 5_000 });
    return stdout.trim() || undefined;
  } catch {
    return undefined;
  }
}
