#!/bin/bash
set -euo pipefail
umask 077

SCRIPT_DIR=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
SOURCE_DIR="$SCRIPT_DIR/app"
SUPPORT_DIR="$HOME/Library/Application Support/Jarvis Demo"
APP_DIR="$SUPPORT_DIR/app"
CONFIG_PATH="$SUPPORT_DIR/config.json"
RUNTIME_DIR="$SUPPORT_DIR/runtime/node-v24.19.0"
PLIST="$HOME/Library/LaunchAgents/com.imclab.jarvis-demo.plist"
LAUNCHER="$HOME/Applications/Jarvis Demo.app"
LOG_DIR="$HOME/Library/Logs/Jarvis Demo"
PORT=48715
OPENAI_SERVICE="com.imclab.jarvis-demo.openai"
SECURITY_BIN="${JARVIS_SECURITY_BIN:-/usr/bin/security}"

if [ "$(uname -s)" != "Darwin" ]; then
  echo "Jarvis Demo requires macOS."
  exit 1
fi
if [ ! -f "$SOURCE_DIR/server.mjs" ]; then
  echo "Installer bundle is incomplete. Keep the app folder beside this installer."
  exit 1
fi

mkdir -p "$SUPPORT_DIR" "$HOME/Library/LaunchAgents" "$HOME/Applications" "$LOG_DIR"

existing_node=""
if command -v node >/dev/null 2>&1; then
  node_major=$(node -p 'process.versions.node.split(".")[0]')
  if [ "$node_major" -ge 22 ]; then existing_node=$(command -v node); fi
fi

if [ -n "$existing_node" ]; then
  NODE_BIN="$existing_node"
else
  NODE_BIN="$RUNTIME_DIR/bin/node"
  if [ ! -x "$NODE_BIN" ]; then
    echo "Installing the pinned Jarvis runtime…"
    case "$(uname -m)" in
      arm64) node_arch="arm64" ;;
      x86_64) node_arch="x64" ;;
      *) echo "Unsupported Mac architecture."; exit 1 ;;
    esac
    archive="node-v24.19.0-darwin-$node_arch.tar.gz"
    download_dir=$(mktemp -d "${TMPDIR:-/tmp}/jarvis-node.XXXXXX")
    trap 'rm -rf "$download_dir"' EXIT
    curl --proto '=https' --tlsv1.2 --fail --location --silent --show-error \
      "https://nodejs.org/dist/v24.19.0/$archive" -o "$download_dir/$archive"
    curl --proto '=https' --tlsv1.2 --fail --location --silent --show-error \
      "https://nodejs.org/dist/v24.19.0/SHASUMS256.txt" -o "$download_dir/SHASUMS256.txt"
    expected=$(awk -v file="$archive" '$2 == file { print $1 }' "$download_dir/SHASUMS256.txt")
    [ -n "$expected" ] || { echo "Could not verify the Node download."; exit 1; }
    (cd "$download_dir" && printf '%s  %s\n' "$expected" "$archive" | shasum -a 256 -c -)
    mkdir -p "$RUNTIME_DIR"
    tar -xzf "$download_dir/$archive" -C "$RUNTIME_DIR" --strip-components=1
    rm -rf "$download_dir"
    trap - EXIT
  fi
fi

if [ -d "$APP_DIR" ]; then
  backup="$SUPPORT_DIR/app-backup-$(date -u +%Y%m%dT%H%M%SZ)"
  mv "$APP_DIR" "$backup"
  echo "Previous app backed up to: $backup"
fi
mkdir -p "$APP_DIR"
ditto "$SOURCE_DIR" "$APP_DIR"

"$NODE_BIN" -e '
  const fs=require("fs");
  const path=process.argv[1];
  let prior={}; try { prior=JSON.parse(fs.readFileSync(path,"utf8")); } catch {}
  fs.writeFileSync(path, JSON.stringify({
    textModel: prior.textModel || "gpt-5.6",
    realtimeModel: prior.realtimeModel || "gpt-realtime-2.1"
  }, null, 2) + "\n", {mode: 0o600});
' "$CONFIG_PATH"

"$NODE_BIN" "$APP_DIR/server.mjs" --self-test

echo
echo "Jarvis needs one OpenAI Platform API key with API billing enabled."
echo "Create a key: https://platform.openai.com/account/api-keys/create"
echo "API billing:  https://platform.openai.com/account/org-settings/organization/billing/overview"
echo "ChatGPT billing is separate from OpenAI API billing."
echo

# One live check of a key against OpenAI through the installed app. Nothing is saved here:
# a key reaches Keychain only after this passes.
verify_openai_key() {
  OPENAI_API_KEY="$1" "$NODE_BIN" "$APP_DIR/server.mjs" --check-openai
}

stored_key=$("$SECURITY_BIN" find-generic-password -a "$USER" -s "$OPENAI_SERVICE" -w 2>/dev/null || true)
replace_key="y"
if [ -n "$stored_key" ]; then
  echo "Checking the saved API key, billing, text model, and Realtime voice access…"
  if verify_openai_key "$stored_key"; then
    read -r -p "Keep the saved OpenAI API key? [Y/n]: " answer
    [[ "$answer" =~ ^[Nn]$ ]] || replace_key="n"
  else
    echo
    echo "The saved OpenAI API key no longer passes the live check, so it will be replaced."
    echo "Create a new key or fix API billing with the links above, then enter the new key."
    read -r -p "Enter a new OpenAI API key now? [Y/n]: " answer
    if [[ "$answer" =~ ^[Nn]$ ]]; then
      echo "Jarvis was not started because the saved OpenAI API key could not be verified."
      exit 1
    fi
  fi
fi

if [ "$replace_key" = "y" ]; then
  read -r -s -p "OpenAI API key: " new_key
  echo
  case "$new_key" in
    sk-*) ;;
    *) echo "That does not look like an OpenAI API key."; exit 1 ;;
  esac
  echo "Checking the API key, billing, text model, and Realtime voice access…"
  if ! verify_openai_key "$new_key"; then
    echo
    echo "Jarvis was not started and the key was not saved because OpenAI setup could not be verified."
    echo "Check the key and API billing links above, then run this installer again."
    exit 1
  fi
  "$SECURITY_BIN" add-generic-password -U -a "$USER" -s "$OPENAI_SERVICE" -w "$new_key" >/dev/null
  echo "The verified key is saved in macOS Keychain."
fi
unset stored_key new_key

# Boot guard for auto-updates: a freshly swapped-in app must pass its self-test, or the previous
# app (kept at app-old by the updater) comes back before the service starts.
LAUNCH_SH="$SUPPORT_DIR/launch.sh"
cat > "$LAUNCH_SH" <<EOF
#!/bin/bash
APP="$APP_DIR"
NODE="$NODE_BIN"
if ! "\$NODE" "\$APP/server.mjs" --self-test >/dev/null 2>&1 && [ -d "\$APP-old" ]; then
  rm -rf "\$APP-broken"
  mv "\$APP" "\$APP-broken"
  mv "\$APP-old" "\$APP"
  echo "\$(date -u +%FT%TZ) rolled back to the previous app after a failed self-test" >&2
fi
exec "\$NODE" "\$APP/server.mjs"
EOF
chmod 700 "$LAUNCH_SH"

"$NODE_BIN" -e '
  const fs=require("fs");
  const esc=s=>String(s).replaceAll("&","&amp;").replaceAll("<","&lt;").replaceAll(">","&gt;");
  const [path,node,server,work,config,out,err]=process.argv.slice(1);
  const item=s=>`<string>${esc(s)}</string>`;
  fs.writeFileSync(path, `<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0"><dict>
<key>Label</key><string>com.imclab.jarvis-demo</string>
<key>ProgramArguments</key><array>${item(node)}${item(server)}</array>
<key>WorkingDirectory</key>${item(work)}
<key>EnvironmentVariables</key><dict><key>JARVIS_CONFIG_PATH</key>${item(config)}</dict>
<key>RunAtLoad</key><true/><key>KeepAlive</key><true/>
<key>StandardOutPath</key>${item(out)}<key>StandardErrorPath</key>${item(err)}
<key>ProcessType</key><string>Interactive</string>
</dict></plist>\n`, {mode: 0o600});
' "$PLIST" /bin/bash "$LAUNCH_SH" "$APP_DIR" "$CONFIG_PATH" "$LOG_DIR/server.log" "$LOG_DIR/server-error.log"

launchctl bootout "gui/$UID" "$PLIST" >/dev/null 2>&1 || true
launchctl bootstrap "gui/$UID" "$PLIST"
launchctl kickstart -k "gui/$UID/com.imclab.jarvis-demo"

if [ -d "$LAUNCHER" ]; then
  mv "$LAUNCHER" "$HOME/.Trash/Jarvis Demo-$(date -u +%Y%m%dT%H%M%SZ).app"
fi
osacompile -o "$LAUNCHER" \
  -e 'on run' \
  -e 'open location "http://127.0.0.1:48715"' \
  -e 'end run'

ready=0
for _ in {1..30}; do
  if curl --silent --fail --max-time 1 "http://127.0.0.1:$PORT/api/status" >/dev/null; then ready=1; break; fi
  sleep 0.25
done
[ "$ready" -eq 1 ] || { echo "Jarvis did not start. See $LOG_DIR/server-error.log"; exit 1; }

open "$LAUNCHER"
echo
echo "Jarvis is installed and OpenAI text plus voice access passed the live setup check."
echo "Load the included demo brief or choose a local file, then start voice."
echo "Launcher: $LAUNCHER"
