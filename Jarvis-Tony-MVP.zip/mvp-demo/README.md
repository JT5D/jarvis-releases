# Jarvis — Tony MVP

This is the fastest real Jarvis demo for today: one local Mac process, one OpenAI API key, local document context, text chat, and live Realtime voice. There is no Google login or cloud setup and no Supabase, Render, database, S3, Firebase, browser extension, Apple signing, or hosted backend.

## Before installing: create the OpenAI key

Tony needs an OpenAI **Platform API key**. ChatGPT and the API have separate billing, so ChatGPT Plus, Pro, Business, or another ChatGPT plan does not by itself fund this demo.

1. Sign in at [Create an OpenAI API key](https://platform.openai.com/account/api-keys/create).
2. Open [OpenAI API Billing](https://platform.openai.com/account/org-settings/organization/billing/overview). If prompted, add payment details or credits. A new balance can take a few minutes to become available.
3. Return to the API key page and select **Create new secret key**.
4. Name it `Jarvis Tony Demo`, leave permissions set to **All** for the simplest reliable demo, and create it.
5. Copy the key and keep it ready for the installer. Never commit it, add it to a GitHub issue, send it in a message, or include it in a screenshot.

If Tony cannot create a key or manage API billing, an owner of his OpenAI API organization must do those steps. No Google account or Google key is needed.

## Install from GitHub

1. Open the [Jarvis Tony MVP release](https://github.com/JT5D/jarvis/releases/tag/tony-mvp-latest).
2. Under **Assets**, download `Jarvis-Tony-MVP.zip`—not either “Source code” archive—and check it as described in **Verify the download** below.
3. Unzip it, open the `mvp-demo` folder, then Control-click `Install Jarvis.command` and choose **Open**. Confirm **Open** if macOS asks.
4. Paste the OpenAI API key when prompted and press Return. Input stays hidden. The installer checks the key against OpenAI first and saves it in macOS Keychain only after that check passes.
5. Wait for `OpenAI text ... and voice ... access verified`, followed by the installation success message. Jarvis opens automatically.
6. For later use, open **Jarvis Demo** from your user Applications folder.

Command-line alternative from the unzipped folder:

```sh
bash "Install Jarvis.command"
```

The GitHub workflow builds and checksum-verifies the release ZIP on macOS. The installer validates or downloads a pinned Node runtime, makes one tiny billable Responses API request and creates a Realtime client session to check the key, saves the key in Keychain only after that check passes, installs a per-user background service, verifies the local server, and opens Jarvis. It does not report success if the key, API billing, text model, or voice model check fails, and it never saves a key that failed. Re-running it updates the app while preserving a timestamped backup, keeps the saved OpenAI key when it still passes the live check, and asks for a new key (the default answer replaces it) when the saved key no longer passes.

## Verify the download

Before opening the ZIP, confirm it is byte-for-byte the file the release workflow built. In Terminal, run:

```sh
shasum -a 256 ~/Downloads/Jarvis-Tony-MVP.zip
```

Compare the 64-character value it prints with the one inside the `Jarvis-Tony-MVP.zip.sha256` asset on the same release page (open that asset in the browser). They must match exactly; if they differ, delete the ZIP and download it again. The release notes also name an immutable tag, `tony-mvp-v<build number>`, that records exactly which commit produced that ZIP.

## Tony's 60-second demo

1. Open **Jarvis Demo** from Applications.
2. The first time, Jarvis asks what to call you, what you do, whether you want brief or detailed answers, and which voice (Marin or Cedar). Select **Continue**. Change any of it later from your name in the top bar.
3. Select **Load included demo brief** for a zero-prep demonstration, or choose a local TXT, Markdown, CSV, JSON, XML, YAML, HTML, or log file under 50 KB.
4. Ask: **“Summarize the launch plan and identify the biggest risk.”** A one-click version of that question appears under the conversation once a source is loaded.
5. Select **Start voice**, approve microphone access, and ask: **“What should Tony do first?”**
6. Optional, and off until you ask for it: tick **See which app I am working in** from your name in the top bar, switch to another window, and ask **“What am I looking at?”** Jarvis reads the window title only — never a screenshot — so macOS asks for Automation permission the first time, not Screen Recording. With remembering also on, you can ask **“What was I working on yesterday?”** after a day of use.
7. Press Space or select **Stop voice**. After your first voice session Jarvis asks once how it went: thumbs up or down and an optional line, saved on this Mac.

The source text, OpenAI response, and voice session are live. The included brief is clearly labeled demo content; the MVP does not fake remote data or actions.

## Sending feedback

**Send feedback** in the top bar opens a new GitHub issue in your browser, prefilled with the last seven days of counts (voice sessions, turns, errors, microphone denials), voice latency from end of speech to first audio (p50, p95, sample size), your latest thumbs rating and note, the app version, and the models in use. It never includes message or document text. Nothing is sent until you read the issue and submit it on GitHub, which needs access to this private repository.

## Restart behavior

Jarvis starts automatically after Tony logs back into his Mac. The OpenAI key remains in Keychain, and the selected local source and the profile (name, role, answer style, voice) remain in private local app storage, so reopening **Jarvis Demo** resumes the demo without setup. Conversation history itself starts fresh.

## Auto-update

Installed copies update themselves. Thirty seconds after start and every six hours, Jarvis reads `manifest.json` from the public [jarvis-releases](https://github.com/JT5D/jarvis-releases) repository, verifies its Ed25519 signature against the key shipped inside the app (`release-key.pem`), and only then downloads the ZIP, checks its SHA-256, unpacks it beside the running app, swaps the folders, and restarts. The previous app stays at `app-old`; if the new build fails its self-test at start, the launcher puts the previous one back. No key, document, profile, or log is touched by an update. A checkout of this repository has no `release.json`, so it never updates; `JARVIS_UPDATES=off` disables checks on an installed copy.

## Troubleshooting

- **OpenAI rejects the key:** create a new project API key with **All** permissions and run the installer again. When the saved key no longer passes the live check, the installer offers to replace it and Return accepts; when it still passes but you want a different key anyway, answer `n` when asked whether to keep it.
- **Billing, credits, or quota is not ready:** check [OpenAI API Billing](https://platform.openai.com/account/org-settings/organization/billing/overview), wait a few minutes after adding credits, then run the installer again. ChatGPT billing is separate.
- **A required model is unavailable:** make sure the key's project can use `gpt-5.6` and `gpt-realtime-2.1`, or ask the OpenAI API organization owner for access.
- **macOS blocks the installer:** Control-click `Install Jarvis.command`, choose **Open**, then confirm **Open**. On macOS 15 Sequoia, if Control-click → **Open** is refused, open **System Settings → Privacy & Security**, scroll to the Security section, click **Open Anyway** next to the blocked installer, and run it again. The MVP is not notarized.
- **Voice cannot hear Tony:** allow microphone access for the browser that opened Jarvis in **System Settings → Privacy & Security → Microphone**, refresh Jarvis, and select **Start voice** again.
- **Jarvis does not open:** confirm the Mac is online, rerun the installer, and check `~/Library/Logs/Jarvis Demo/server-error.log` if it still fails.

## Scope held for the full product

- Google Drive, Gmail, Calendar, GitHub, and organization login
- “Hey Jarvis” wake word and background activation
- screen/Accessibility context across apps
- persistent conversation memory and multi-user cloud sync
- document/slide/PDF generation and external actions
- notarized DMG and auto-update

## Security posture

- binds only to `127.0.0.1:48715` and rejects non-loopback hosts;
- stores the OpenAI key in macOS Keychain, and only after it passes the live check;
- stores selected source text, the profile, and the usage and feedback logs only in private local app storage with owner-only permissions;
- writes only counts and timings to the usage log (`usage.jsonl`); the server drops every other field, so no message or document text can reach it;
- never sends the standard OpenAI API key to browser JavaScript;
- treats attached text and the profile as untrusted evidence, not model instructions.

What leaves the Mac, and when:

- while voice shows **Listening…**, the microphone streams continuously to OpenAI's Realtime API until you press Space or select **Stop voice**; there is no push-to-talk;
- the whole selected document (truncated at 30,000 characters) is sent to OpenAI with every text message and at the start of every voice session, not only the parts you ask about;
- with **See which app I am working in** switched on (it is off until you switch it on), the name of the frontmost app and the title of its front window are read and sent to OpenAI with your question, and refreshed on each turn of a voice session. Jarvis takes no screenshot and reads no pixels — this needs macOS Automation permission, not Screen Recording. A window title is still more revealing than an app name: it routinely carries document names, file paths, branch names, URLs and email subject lines;
- with sight **and** remembering both on, that app and window title are also written to `memory.jsonl` with the date whenever you move to different work, and can be sent back to OpenAI later when you ask what you were working on. Switching sight off stops both the sending and the writing;
- text requests are sent with `store: false`, but the Realtime voice sessions are not configured with `store: false`, so OpenAI's default data retention applies to voice;
- every text answer, and every observation described above, is kept on this Mac in `memory.jsonl`, and the three past turns most relevant to your question are sent to OpenAI with it, so an old conversation can leave the Mac again later; **Forget everything** in the profile card and `Uninstall Jarvis.command` both delete that file;
- pressing Space anywhere in the page, outside a text field or button, starts or stops the microphone, so a stray keypress can open the mic;
- the background service starts at every login and keeps running on port 48715 (restarting itself if it stops) until you run `Uninstall Jarvis.command`;
- every six hours the service fetches `manifest.json` (a few hundred bytes) from `raw.githubusercontent.com`; it downloads the release ZIP only when a newer, correctly signed build exists. Nothing about you is sent in that request.

Run `Uninstall Jarvis.command` to stop the service, move installed files to Trash, delete the selected source text (`context.json`), the profile (`profile.json`), the usage and feedback logs (`usage.jsonl`, `feedback.jsonl`), the conversation memory (`memory.jsonl`), and the logs in `~/Library/Logs/Jarvis Demo`, and remove saved credentials.
