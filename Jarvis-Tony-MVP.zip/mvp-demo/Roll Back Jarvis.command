#!/bin/bash
set -euo pipefail
support="$HOME/Library/Application Support/Jarvis Demo"
plist="$HOME/Library/LaunchAgents/com.imclab.jarvis-demo.plist"
shopt -s nullglob
backups=("$support"/app-backup-*)
if [ ${#backups[@]} -gt 0 ]; then
  previous="${backups[${#backups[@]}-1]}"
elif [ -d "$support/app-old" ]; then
  previous="$support/app-old"
else
  echo 'No previous Jarvis app backup exists.'
  exit 1
fi
[ -f "$previous/server.mjs" ] || { echo 'Backup is incomplete.'; exit 1; }
launchctl bootout "gui/$UID" "$plist" >/dev/null 2>&1 || true
mv "$support/app" "$support/app-before-rollback-$(date -u +%Y%m%dT%H%M%SZ)"
cp -R "$previous" "$support/app"
/usr/libexec/PlistBuddy -c 'Add :EnvironmentVariables:JARVIS_UPDATES string off' "$plist" 2>/dev/null || /usr/libexec/PlistBuddy -c 'Set :EnvironmentVariables:JARVIS_UPDATES off' "$plist"
launchctl bootstrap "gui/$UID" "$plist"
launchctl kickstart -k "gui/$UID/com.imclab.jarvis-demo"
echo 'Previous app restored; automatic updates paused. Key and profile preserved.'
open 'http://127.0.0.1:48715'
