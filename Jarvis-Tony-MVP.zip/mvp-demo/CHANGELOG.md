# Changelog — Jarvis Tony MVP

Every build a person can install, newest first. Installed copies **update themselves silently**
every six hours (since `tony-mvp-v17`), so this file is the only way to find out what changed under
you.

Each entry names the mechanism, not the mood: what actually broke or changed, in terms you could
verify. "Improved reliability" is not an entry.

Build numbers come from the release workflow's run counter, which also counts pull-request runs, so
they skip. A skipped number is not a missing release. Where the version tag itself failed to publish
the ZIP still shipped, and that is noted.

## tony-mvp-v40 — 2026-09-13

- Answer general questions directly, including spelling, without requiring a document.
- Live web search for current news in text and through the voice news tool.
- Current perception overrides historical observations; unavailable sight explicitly means blindness.
- Replace voice sight context before responding; never retain old sight events as current.
- Preserve Keychain/profile on reinstall and pin verified OpenAI model defaults.
- Keep this release on the legacy updater; native migration is disabled.

## tony-mvp-v39 — 2026-09-05

- **The list of what leaves your Mac now includes sight.** Since v35 Jarvis has been able to read
  the name of the app in front of you and the title of its window and send that to OpenAI with your
  question, and since v37 to write it down and send it back later. The README has a section that
  lists everything that leaves this Mac and when, and it never mentioned any of that. It does now —
  including the part you cannot work out for yourself: a window title is not the same as an app
  name. It routinely carries document names, file paths, branch names, URLs and email subject
  lines.
- **"Forget everything" now says what it actually deletes.** The confirmation read "Saved
  conversations deleted" while it was also deleting the record of which apps you had been working
  in. Same button, same file, an honest sentence.
- **Nothing about how Jarvis behaves changed in this build.** Sight is still off until you switch it
  on, still reads titles and never a screenshot, and still asks macOS for Automation permission
  rather than Screen Recording. This build changes what you were told, not what was done.

## tony-mvp-v38 — 2026-09-05

- **Asking about something you actually said works again after a couple of busy weeks.** Your
  conversations and the notes about what you were working in shared a single 400-line window, and
  app switches arrive far faster than questions do. About ten days of ordinary work filled that
  window entirely with activity, after which recall of a past conversation quietly returned
  nothing — no error, no warning, just silence where an answer used to be. Each kind now keeps its
  own history, 400 conversations and 200 observations, so a busy day at the keyboard can no longer
  cost you something you were told.
- **Jarvis reads the end of its memory file instead of all of it.** The file is only ever appended
  to and never trimmed, yet every question re-read the whole thing in order to use the last few
  hundred lines — work that grew a little every day you used it. Measured on a year of heavy use,
  that read went from 32 MB and 25.6 ms to 2 MB and 1.8 ms. Nothing you can recall changed; only
  the cost of recalling it.
- **A copy that cannot start its own auto-updater now says so and keeps working, instead of
  quitting.** Arming the updater was the last thing the app did at startup, and nothing caught a
  failure there, so an unreadable signing key stopped the process — and launchd would restart it
  straight back into the same failure. The launcher already puts the previous build back when one
  is on disk to put back; this covers the case where there is not. It now serves normally and
  writes one plain line to the log saying this copy will not receive updates.

## tony-mvp-v37 — 2026-09-05

- Jarvis now remembers what you were working in, so you can ask **"what was I working on
  yesterday?"** and get an answer. Until now sight was spent entirely on the current question and
  then thrown away, which made it a lookup rather than a memory — and forgetting is the one thing a
  chat assistant that sees your screen for a single turn already does.
- What is written down is a transition, not a sample: the app and window title at the moment you
  move to different work, never every question you ask. Switching files inside one editor changes
  the window title constantly, so the same app is only written down again after five minutes. A day
  of work is a handful of lines, not four hundred.
- It is recalled as history and never as the present — "On 2026-09-04 14:32 they were working in
  Windsurf on WarpJobs". A dated observation stays true. The same sentence in the present tense
  stops being true the moment you switch windows, which is why the previous build kept nothing.
- Questions about time reach it. "What was I working on yesterday" shares no words with "Windsurf",
  so the search that finds past answers scores it zero; a question about _when_ now retrieves the
  recent record instead. A question about a topic pulls none of it, so nothing is sent for nothing.
- It lives in the same file as your conversations, under the same **Remember our conversations**
  switch and the same **Forget everything** button. Switch remembering off and nothing about any
  other application is written down, even with sight on.

## tony-mvp-v36 — 2026-09-05

- Switching on **See which app I am working in** now tells you whether it actually worked. macOS
  asks once for permission to control System Events, and if that is refused — or simply never
  appears — sight silently does nothing: Jarvis keeps answering that it cannot see your screen, and
  nothing says why or that there is a setting to change. It now confirms out loud, naming the app it
  can see, or tells you exactly where to allow it: System Settings > Privacy & Security >
  Automation. This is the same treatment a blocked microphone already got, and v35 shipped without
  it.
- The usage log records whether sight worked when it was switched on, and nothing else about it.
  Counts only — never an app name, never a window title. It exists so the question "is reading the
  window title enough, or does Jarvis need to read the screen itself?" can be answered with evidence
  rather than a guess.

## tony-mvp-v35 — 2026-09-04

- Jarvis can tell which app you are working in. With the new **See which app I am working in**
  checkbox switched on, each question carries the name and title of your frontmost window — for
  example `Windsurf` / `WarpJobs` — so "why is this failing?" is answered about the thing in front
  of you instead of in the abstract. It is **off until you switch it on**, unlike remembering, which
  defaults on: nothing about your other applications has ever been sent before, so there is no
  earlier behaviour to preserve and silence is the safe default. macOS will ask once for permission
  to control System Events; refusing it leaves Jarvis working exactly as before.
- What Jarvis reads is the window _title only_. There is no screenshot, no screen recording
  permission, and nothing from inside the window — not the text, not the pixels. A title is also
  text written by other applications, so it is treated as untrusted evidence and cannot open or
  close the source fence.
- What was on screen is sent with the question and never stored. Kept in the conversation it would
  be replayed on later turns, stating with total confidence that you are still in an app you left
  ten minutes ago.
- Spoken questions carry it too, refreshed on every turn. A voice session is given its instructions
  once when it starts, so a window title placed there would be frozen at whatever was in front of
  you when you pressed Start voice. Instead the window is read and sent into the live conversation
  the moment you _begin_ speaking: the read takes about 170ms and a sentence takes seconds, so it
  has landed before you finish — and OpenAI starts answering the instant you stop, which leaves no
  safe gap afterwards. Switch to another app mid-conversation and the next thing you say is
  answered about the new one.

- When the window cannot be read — permission refused, or the read timed out — Jarvis is told
  plainly that it cannot see, and says so. It is not left to guess. Jarvis v1 once answered a
  question about a screen it could not see by inventing "a document, a screenshot, and a terminal
  window named WarpJobs"; asking a model not to invent did not fix that, and stating the blindness
  does.

## tony-mvp-v34 — 2026-09-04

- Voice now stops itself after 3 minutes of silence, or 30 minutes of conversation. There is no
  push-to-talk, so a microphone left open by someone who walked away billed OpenAI for audio until
  the tab was closed — verified at $0.0192 per minute heard, about $1.15 an hour, with no upper
  bound. The guard is a clock rather than a spend cap on purpose: metering tokens needs a price
  table, and a stale rate silently mis-sizes the cap.

## tony-mvp-v31 — 2026-09-04 (`f339d1d`)

- Remembering past conversations is now a setting you can see and switch off, in the same card that
  asks your name. It stays on by default, and a profile saved before this existed keeps remembering.
  **Forget everything** deletes the saved conversations outright, without switching anything off.
  Introduced in v23, remembering had no visible control and arrived through a silent auto-update.
- Cut from this Mac rather than CI: GitHub Actions was blocked on an account spending limit, so this
  build was published with `scripts/cut-release-local.sh`. Same steps, same signing key, same
  checks.

## tony-mvp-v23 — 2026-09-04 (`810f5a2`)

- Long-term memory: text answers are kept on this Mac in `memory.jsonl` and the three past turns
  most relevant to a question are sent with it, so an old conversation can leave the Mac again
  later. `Uninstall Jarvis.command` deletes the file.
- The source fence id is now minted once when a source is attached instead of on every request. The
  per-request id changed the start of the prompt each turn, which meant OpenAI's prompt cache could
  never match and the whole document was reprocessed every time, at full latency and full cost.

## tony-mvp-v21 — 2026-09-04 (`a9a6452`)

- Fixed a test that accepted a forged auto-update roughly 1 run in 64. The suite forged its test
  signature by replacing the first base64 character with `A`; when the real signature already began
  with `A` the "tampered" signature was byte-identical to the valid one, so the updater correctly
  installed it and the test failed. Signature verification itself was never wrong — the gate that
  guards it was flaky, in the check that decides whether a forged update reaches every Mac.
- The shipped screen now has an automated gate. `scripts/qa-demo-ui.mjs` renders the real page in a
  browser and checks first run, profile personalisation, the demo brief, the voice control and
  WCAG AA contrast; `--teeth` breaks each one on purpose to prove the checks can fail.

## tony-mvp-v18 — 2026-09-04 (`b03ccf5`)

- The immutable per-build tag now publishes. The previous step read a 404 response body as if it
  were an existing tag, so no build before this one carries one.

## tony-mvp-v17 — 2026-09-04 (`35f7c37`) — ZIP shipped, tag step failed

- **Automatic updates.** Installed copies check a signed manifest on boot and every six hours,
  verify an Ed25519 signature and a SHA-256 checksum before swapping, and keep the previous build.
  A boot guard restores the old build if the new one fails to start. This is the last build anyone
  had to install by hand.

## tony-mvp-v15 — 2026-09-04 (`d271293`) — ZIP shipped, tag step failed

- First-run card asks your name, role, answer style and voice; the prompt and voice follow it. Every
  build before this greeted every user as "Tony", hardcoded.
- Local usage log (`usage.jsonl`) records counts and timings only, and **Send feedback** prefills a
  reviewable issue.

## tony-mvp-v12 — 2026-09-04 (`7f74911`) — ZIP shipped, tag step failed

- The installer verifies an API key against OpenAI before saving it to the Keychain, rather than
  saving it and failing later.
- Uninstall now deletes the saved document text, profile and logs instead of leaving them behind.

## tony-mvp-v10 — 2026-09-04 (`306c979`)

- POSTs without an `Origin` header are refused with 403, so another page in the browser cannot drive
  the local server.
- The attached document is wrapped in a fence carrying a random id, so text inside a document cannot
  close the wrapper and address the model directly.

## tony-mvp-v8 — 2026-09-04 (`501a3a3`)

- Fixed a crash loop. Four route handlers returned unawaited promises, so the first OpenAI error
  killed the process and launchd restarted it every ten seconds. Any build before this one
  crash-loops the first time OpenAI returns an error.

## tony-mvp-v6 and earlier — 2026-09-02

Commits `30635b5`, `eb5a083`, `3b811b2`, `7457e5f`, `3446576`, `6cca6c4`.

First shipped installer: a local Node server, an OpenAI-only text and voice demo over a local
document, delivered as a ZIP with a checksum. Superseded — see `tony-mvp-v8`, which fixed the crash
loop these builds all have.
