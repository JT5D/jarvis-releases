#!/bin/bash
set -euo pipefail

ROOT=$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)
MVP="$ROOT/mvp-demo"
OUT="${1:-$ROOT/dist}"
APP="$OUT/Jarvis Installer.app"
ZIP="$OUT/Jarvis-Executive-Preview.zip"
KEYCHAIN="$RUNNER_TEMP/jarvis-signing.keychain-db"
CERT="$RUNNER_TEMP/jarvis-developer-id.p12"
NOTARY_KEY="$RUNNER_TEMP/AuthKey_${APPLE_NOTARY_KEY_ID}.p8"

required=(
  APPLE_DEVELOPER_ID_P12_BASE64
  APPLE_DEVELOPER_ID_P12_PASSWORD
  APPLE_DEVELOPER_ID_APPLICATION
  APPLE_NOTARY_KEY_ID
  APPLE_NOTARY_ISSUER_ID
  APPLE_NOTARY_KEY_P8_BASE64
)
for name in "${required[@]}"; do
  if [ -z "$(printenv "$name" 2>/dev/null || true)" ]; then
    echo "Missing required signing secret: $name" >&2
    exit 2
  fi
done

rm -rf "$OUT"
mkdir -p "$OUT"

cat > "$RUNNER_TEMP/JarvisInstaller.applescript" <<'APPLESCRIPT'
on run
  set appPath to POSIX path of (path to me)
  set installerPath to appPath & "Contents/Resources/mvp-demo/Install Jarvis.command"
  tell application "Terminal"
    activate
    do script quoted form of installerPath
  end tell
end run
APPLESCRIPT

osacompile -o "$APP" "$RUNNER_TEMP/JarvisInstaller.applescript"
mkdir -p "$APP/Contents/Resources"
ditto "$MVP" "$APP/Contents/Resources/mvp-demo"
chmod +x "$APP/Contents/Resources/mvp-demo/Install Jarvis.command" "$APP/Contents/Resources/mvp-demo/Uninstall Jarvis.command"

# Import the Developer ID certificate into an isolated CI keychain.
printf '%s' "$APPLE_DEVELOPER_ID_P12_BASE64" | base64 -D > "$CERT"
security create-keychain -p jarvis-ci "$KEYCHAIN"
security set-keychain-settings -lut 21600 "$KEYCHAIN"
security unlock-keychain -p jarvis-ci "$KEYCHAIN"
security import "$CERT" -k "$KEYCHAIN" -P "$APPLE_DEVELOPER_ID_P12_PASSWORD" -T /usr/bin/codesign -T /usr/bin/security
security set-key-partition-list -S apple-tool:,apple:,codesign: -s -k jarvis-ci "$KEYCHAIN"
existing_keychains=$(security list-keychains -d user | tr -d '"')
security list-keychains -d user -s "$KEYCHAIN" $existing_keychains

codesign --force --deep --options runtime --timestamp \
  --sign "$APPLE_DEVELOPER_ID_APPLICATION" \
  "$APP"

codesign --verify --deep --strict --verbose=2 "$APP"

# Notarize the signed app as a ZIP, staple the ticket, then create the final client ZIP.
printf '%s' "$APPLE_NOTARY_KEY_P8_BASE64" | base64 -D > "$NOTARY_KEY"
PRE_NOTARY="$OUT/Jarvis-Executive-Preview-notary.zip"
ditto -c -k --sequesterRsrc --keepParent "$APP" "$PRE_NOTARY"

xcrun notarytool submit "$PRE_NOTARY" \
  --key "$NOTARY_KEY" \
  --key-id "$APPLE_NOTARY_KEY_ID" \
  --issuer "$APPLE_NOTARY_ISSUER_ID" \
  --wait

xcrun stapler staple "$APP"
xcrun stapler validate "$APP"
spctl --assess --type execute --verbose=4 "$APP"

ditto -c -k --sequesterRsrc --keepParent "$APP" "$ZIP"
shasum -a 256 "$ZIP" > "$ZIP.sha256"
rm -f "$PRE_NOTARY"

echo "Built notarized installer: $ZIP"
